/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package forceconstants;

import ForceConstantsIO.GaussianDataIO;
import ForceView.AnglePanel;
import ForceView.ButtonPanel;
import ForceView.DetailPanel;
import ForceView.DistancePanel;
import ForceView.FilePanel;
import ForceView.ForceFrame;
import ForceView.ForceThread;
import ForceView.OutputPanel;
import ForceView.SplashWindow;
import Jama.EigenvalueDecomposition;
import Jama.Matrix;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.text.MaskFormatter;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;
import org.apache.commons.math3.linear.*;

/**
 *
 * Force constant for bond stretching in AMBER is kcal/mol/A^2
 * Hessian (force constant matrix) in Gaussian is in Hartree/bohr^2 and are not yet mass-weighted.
 * 
 * @author acnash
 */
public class ForceConstants implements Runnable {

    
    private int fixedAtom;// = 1; //atom that feels the force of displacement
    private int displacedAtomA;// = 2; //the displacement of atom A causes a force on the fixed atom
    private int displacedAtomC;// = 3;
    
    private static final int NORMAL_MODE = 1; 
    
    public static final double bohr_squar_to_angstrom_square = 0.280029;
    public static final double hartree_to_kcalmol = 627.509;
    public static final double conversion = hartree_to_kcalmol/bohr_squar_to_angstrom_square;
    
    
    //public static final double conversionFactor = 2240.874995;
    //public static final double conversionFactorB = 1185.80928;
    public static final double HFScaling = 0.8929;
    public static final double B3LYPScaling = 0.8929;
    
    public static final int DISTANCE = 0;
    public static final int ANGLE = 1;
    //H2O - B3LYP
    
    private boolean isFCHKFound = false;
    private boolean isLOGFound = false;
    
    private BuildHessian buildHessian = null;
    
    private ForceFrame forceFrame = null;
    private FilePanel filePanel = null;
    private DetailPanel detailPanel = null;
    private OutputPanel outputPanel = null;
    private ButtonPanel buttonPanel = null;
    
    private final JButton fchkButton = new JButton(".fchk File");
    private final JButton logButton = new JButton(".out/.log File");
    private final JButton fcButton = new JButton("Calculate");
    private final JButton exitButton = new JButton("Close");
    
    private final JTextField fchkTextField = new JTextField(35);
    private final JTextField logTextField = new JTextField(35);
    
    private final String[] comboNames = {"Bond Stretch", "Bond Angle"};
    private final JComboBox angleDistanceComboBox = new JComboBox(comboNames);
    
    private DistancePanel distancePanel = null;// = new DistancePanel();
    private AnglePanel anglePanel = null;
    
    private final JCheckBox weightCheckBox = new JCheckBox("Mass Weighted Hessian",false);
    private final JTextField scalarTextField = new JTextField();
    
    //for distance
    private JTextField fixedAtomDistanceTextField = null;
    private JTextField displacedAtomDistanceTextField = null;
    private JFormattedTextField fixedAtomAngleTextField = null;
    private JFormattedTextField displacedAtomAAngleTextField = null;
    private JFormattedTextField displacedAtomCAngleTextField = null;
    
    private final JButton fullButton = new JButton("Full structure");
    private final JButton fileButton = new JButton("Atom data");

    private final JFileChooser fcLog = new JFileChooser();
    private final JFileChooser fcFCHK = new JFileChooser();
    private final JFileChooser fcAtomData = new JFileChooser();
    private File logFile = null;
    private File fchkFile = null;
    private File atomFile = null;
    
    private SplashWindow s = null;
    
    private GaussianDataIO gaussianDataIO = null;
    
    //0 is distance
    //1 is angle
    public static int selectedAngleDistance = DISTANCE;
    
    private String[][] distanceCoords = new String[2][3];
    private String[][] angleCoords = new String[3][3];
    
    private Thread thread = null;
    private boolean allBonds = false;
    private boolean bondFromFile = false;
    
    private double angleGromacs = 0;
    private double angleAmber = 0;
    private double distanceGromacs = 0;
    private double distanceAmber = 0;
    
    private boolean calculateByMass = false;
    
    
    public ForceConstants() {
        GridBagLayout gbLayout = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        
        thread = new Thread(this);
        //s = new SplashWindow(null,forceFrame);
        
        forceFrame = new ForceFrame();
        forceFrame.setLayout(gbLayout);
        
        filePanel = new FilePanel();
        filePanel.setFCHKFileButton(fchkButton);
        filePanel.setLOGFileButton(logButton);
        filePanel.setFCHKTextField(fchkTextField);
        filePanel.setLOGTextField(logTextField);  
        filePanel.setupGUI();
        
        fchkTextField.setEnabled(false);
        logTextField.setEnabled(false);
        fixedAtomDistanceTextField = new JTextField(3);
        displacedAtomDistanceTextField = new JTextField(3);
        
        
        fixedAtomAngleTextField = new JFormattedTextField();
        displacedAtomAAngleTextField = new JFormattedTextField();
        displacedAtomCAngleTextField = new JFormattedTextField();
        
        fullButton.addActionListener(getCalcAllButtonAL());
        fullButton.setEnabled(false);
        fileButton.addActionListener(getCalcFromFileAL());
        
        weightCheckBox.addActionListener(getWeightCheckBoxAL());
        
        distancePanel = new DistancePanel(fixedAtomDistanceTextField, displacedAtomDistanceTextField);
        distancePanel.setOpaque(false);
        anglePanel = new AnglePanel(fixedAtomAngleTextField, displacedAtomAAngleTextField, displacedAtomCAngleTextField);
        anglePanel.setOpaque(false);
        angleDistanceComboBox.addActionListener(getAngleDistanceComboBoxAL());
        detailPanel = new DetailPanel(distancePanel, angleDistanceComboBox,fullButton,weightCheckBox,scalarTextField);//,fileButton);
        
        outputPanel = new OutputPanel();
        
        fcButton.addActionListener(getFCButtonAL());
        exitButton.addActionListener(getExitButtonAL());
        buttonPanel = new ButtonPanel();
        buttonPanel.setCalculateFCButton(fcButton);
        buttonPanel.setExitButton(exitButton);
        buttonPanel.setCalculateFileButton(fileButton);
        
        fileButton.setEnabled(false);
        fcButton.setEnabled(false);
        
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth=10;
        constraints.gridheight=1;
        forceFrame.add(filePanel, constraints);
        
        constraints.gridx=0;
        constraints.gridy=1;
        constraints.gridwidth=1;
        constraints.gridheight=4;
        constraints.fill = GridBagConstraints.BOTH;
        forceFrame.add(detailPanel, constraints);
        
        constraints.gridx=0;
        constraints.gridy=5;
        constraints.gridwidth=10;
        constraints.gridheight=1;
        forceFrame.add(buttonPanel,constraints);
        
        constraints.gridx=1;
        constraints.gridy=1;
        constraints.gridwidth=9; //5
        constraints.gridheight=4; //3
        
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());
        constraints.fill = GridBagConstraints.BOTH;
        Dimension dim = new Dimension();
        dim.setSize(500, 400);
        
        outputPanel.setPreferredSize(dim);
        JScrollPane scroll = new JScrollPane(outputPanel);
        scroll.setPreferredSize(dim);
        
        forceFrame.add(scroll, constraints);
        
        filePanel.setFCHKButtonAL(getFCHKButtonAL());
        filePanel.setLOGButtonAL(getLOGButtonAL());
        
        forceFrame.startGUI();
        
        gaussianDataIO = GaussianDataIO.getInstance(outputPanel);
    }
    
    @Override
    public void run() {
        if(bondFromFile == true) {
            bondFromFile = false;
            try {
                startFileForceConstants();
            } catch(IOException exp) {
                exp.printStackTrace();
            }
        } else {
        
            if(allBonds == false) {
                startForceConstants();
            } else {
                allBonds = false;
                startAllBondForceConstants();
            }
        }
        outputPanel.updateText();
        s.setVisible(false);
        thread = new Thread(this);
        //SplashWindow s = new SplashWindow(null,forceFrame);
        //s.setVisible(true);
        //s.pack();
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    /**
     * 
     */
    private void startFileForceConstants() throws IOException {
        fcAtomData.setFileFilter(new javax.swing.filechooser.FileFilter() {
            @Override
            public boolean accept(File pathname) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                
                return pathname.getName().toUpperCase().endsWith(".DAT");
            }

            @Override
            public String getDescription() {
                return "FC atom data files (.dat)";
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        int returnValue = fcAtomData.showOpenDialog(forceFrame);
        if(returnValue == JFileChooser.APPROVE_OPTION) {
            atomFile = fcAtomData.getSelectedFile();
            outputPanel.setText("FC atom data file selected: " + atomFile.getName() + "\n");
            //try {
            gaussianDataIO.setAtomDataFile(atomFile);
                //fchkTextField.setText(fchkFile.getAbsolutePath());
            //} catch(FileNotFoundException exp) {
            //    exp.printStackTrace();
                //System.out.println(exp.toString());
            //} catch(IOException exp) {
            //    exp.printStackTrace();
            //}
        } else {
            return;
        }
        
        ArrayList<int[]> atomList = null;
        ListIterator<int[]> listIterator = null;
        if(selectedAngleDistance == DISTANCE) {
            atomList = (ArrayList) gaussianDataIO.getStretchList();
            listIterator = atomList.listIterator();
            ArrayList fcAmberList = new ArrayList();
            ArrayList fcGromacsList = new ArrayList();
            ArrayList distanceAngleList = new ArrayList();
            while(listIterator.hasNext()) {
                int[] ids = listIterator.next();
                fixedAtom = ids[0];
                displacedAtomA = ids[1];
                String[] stringIDs = new String[2];
                stringIDs[0] = Integer.toString(ids[0]);
                stringIDs[1] = Integer.toString(ids[1]);
                
                distanceCoords = gaussianDataIO.getXYZcoords(DISTANCE, stringIDs);
                double distance = FCUtils.determineBondLength(distanceCoords);
                distanceAngleList.add(distance);
                
                startForceConstants();
                fcAmberList.add(distanceAmber);
                fcGromacsList.add(distanceGromacs);
            }
            gaussianDataIO.outputFCDistanceAngle(fcAmberList, fcGromacsList, distanceAngleList, DISTANCE);
        } else {
            atomList = (ArrayList) gaussianDataIO.getAngleList();
            listIterator = atomList.listIterator();
            ArrayList fcAmberList = new ArrayList();
            ArrayList fcGromacsList = new ArrayList();
            ArrayList distanceAngleList = new ArrayList();
            while(listIterator.hasNext()) {
                int[] ids = listIterator.next();
                fixedAtom = ids[1];
                displacedAtomA = ids[0];
                displacedAtomC = ids[2];
                String[] stringIDs = new String[3];
                stringIDs[0] = Integer.toString(ids[1]);
                stringIDs[1] = Integer.toString(ids[0]);
                stringIDs[2] = Integer.toString(ids[2]);
                
                //YET TO IMPLEMENT ANGLE?!
                angleCoords = gaussianDataIO.getXYZcoords(ANGLE, stringIDs);
                double angle = FCUtils.determineAngle(angleCoords);
                distanceAngleList.add(angle);
                
                startForceConstants();
                fcAmberList.add(angleAmber);
                fcGromacsList.add(angleGromacs);
            }
            gaussianDataIO.outputFCDistanceAngle(fcAmberList, fcGromacsList, distanceAngleList, ANGLE);
        }
        
        
    }
    
    public ActionListener getWeightCheckBoxAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                AbstractButton abstractButton = (AbstractButton) e.getSource();
                calculateByMass = abstractButton.getModel().isSelected();
                System.out.println(calculateByMass);
            }
            
        };
    }
    
    public ActionListener getAngleDistanceComboBoxAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox selectedBox = (JComboBox)e.getSource();
                int selectedCombo = selectedBox.getSelectedIndex();
                
                //detailPanel.removeExistingPanel(distancePanel);
                
                
                if(selectedCombo == DISTANCE) {
                    //if(selectedAngleDistance == ANGLE) {
                        detailPanel.addDistanceAnglePanel(distancePanel);
                        detailPanel.removeExistingPanel(anglePanel);
                        selectedAngleDistance = DISTANCE;
                    //}
                } else {
                    //if(selectedAngleDistance == DISTANCE) {
                        detailPanel.addDistanceAnglePanel(anglePanel);
                        detailPanel.removeExistingPanel(distancePanel);
                        selectedAngleDistance = ANGLE;
                    //}
                }
                
                detailPanel.updateUI();
                forceFrame.pack();
                
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
            
        };
    }
    
    private ActionListener getCalcFromFileAL() {
        return new ActionListener() {
            /**
            *
            * @param e
            */
            public void actionPerformed(ActionEvent e) {
                bondFromFile = true;
                //if(selectedAngleDistance == DISTANCE) {
                    s = new SplashWindow(null,forceFrame);
                    s.setVisible(true);
                    thread.start();
                //}
            }
        };
    }
    
    private ActionListener getCalcAllButtonAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                allBonds = true;
                //distance based
                //if(selectedAngleDistance == DISTANCE) {
                s = new SplashWindow(null,forceFrame);
                s.setVisible(true);
                thread.start();
                //} else {
                    //angle based
                    //JOptionPane.showMessageDialog(forceFrame, "Full angle calculations not yet implemented.", null, JOptionPane.WARNING_MESSAGE);
                //}
                
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
            
        };
    }
    
    private ActionListener getFCButtonAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                
                selectedAngleDistance = angleDistanceComboBox.getSelectedIndex();
                
                if(selectedAngleDistance == DISTANCE) {
                    if(checkForDistanceParameters() == true) {
                        //run the force constant calculations
                        String[] atomIDs = new String[2];
                        atomIDs[0] = fixedAtomDistanceTextField.getText();
                        atomIDs[1] = displacedAtomDistanceTextField.getText();
                        
                        //return if the atoms are empty
                        
                        try {
                            distanceCoords = gaussianDataIO.getXYZcoordsBohr(DISTANCE, atomIDs);
                            //detailPanel.setCoords(distanceCoords, DISTANCE);
                            
                            s = new SplashWindow(null,forceFrame);
                            s.setVisible(true);
                            thread.start();
                        } catch(IOException | NullPointerException exp) {
                            JOptionPane.showMessageDialog(forceFrame,"Unable to acquire coordinates. Has log file been loaded?", "Coordinate error.", JOptionPane.ERROR_MESSAGE);
                            //System.out.println(exp.toString());
                        }
                        
                    } else {
                        //System.out.println("Stretch bond parameters incorrect.");
                        JOptionPane.showMessageDialog(forceFrame, "Empty or incorrect bond stretch parameter.","Parameter error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    if(checkForAngleParameters() == true) {
                        //run the force constant calculations
                        String[] atomIDs = new String[3];
                        atomIDs[0] = fixedAtomAngleTextField.getText();
                        atomIDs[1] = displacedAtomAAngleTextField.getText();
                        atomIDs[2] = displacedAtomCAngleTextField.getText();
                        
                        //return if the atoms are empty
                        
                        try {
                            angleCoords = gaussianDataIO.getXYZcoordsBohr(ANGLE, atomIDs);
                            //detailPanel.setCoords(angleCoords, ANGLE);
                            s = new SplashWindow(null,forceFrame);
                            s.setVisible(true);
                            thread.start();
                            //startForceConstants();
                        } catch(IOException | NullPointerException exp) {
                            JOptionPane.showMessageDialog(forceFrame,"Unable to acquire coordinates. Has log file been loaded?", "Coordinate error.", JOptionPane.ERROR_MESSAGE);
                            //System.out.println(exp.toString());
                        }
                    } else {
                        //System.out.println("Bond angle parameters incorrect.");
                        JOptionPane.showMessageDialog(forceFrame, "Empty or incorrect bond angle parameter.","Parameter error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                //this is where everything needs to be checked
                
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
            
        };
    }
    
    private boolean checkForDistanceParameters() {
        String fixedAtomString = fixedAtomDistanceTextField.getText();
        String displacedAtomTextField = displacedAtomDistanceTextField.getText();
        if(fixedAtomString.isEmpty() == true || displacedAtomTextField.isEmpty() == true) {
            return false;
        }
        try {
            fixedAtom = Integer.valueOf(fixedAtomString);
            displacedAtomA = Integer.valueOf(displacedAtomTextField);
        } catch(NumberFormatException exp) {
            return false;
        }
        
        return true;
    }
    
    private boolean checkForAngleParameters() {
        String fixedAtomString = fixedAtomAngleTextField.getText();
        String displacedAtomATextField = displacedAtomAAngleTextField.getText();
        String displacedAtomCTextField = displacedAtomCAngleTextField.getText();
        if(fixedAtomString.isEmpty() == true || displacedAtomATextField.isEmpty() == true || displacedAtomCTextField.isEmpty() == true) {
            return false;
        }
        try {
            fixedAtom = Integer.valueOf(fixedAtomString);
            displacedAtomA = Integer.valueOf(displacedAtomATextField);
            displacedAtomC = Integer.valueOf(displacedAtomCTextField);
        } catch(NumberFormatException exp) {
            return false;
        }
        
        return true;
    }
    
    private ActionListener getExitButtonAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //System.out.println(outputPanel.getSize().toString());
                System.exit(0);
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
            
        };
    }
    
    private ActionListener getLOGButtonAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("LOGFile");
                fcLog.setFileFilter(new javax.swing.filechooser.FileFilter() {

                    @Override
                    public boolean accept(File pathname) {
                        if(pathname.getName().toUpperCase().endsWith(".LOG") || pathname.getName().toUpperCase().endsWith(".OUT") ) {
                            return true;
                        }
                        
                        return false;
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }

                    @Override
                    public String getDescription() {
                        return "Gaussian .log or .out files";
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }
                    
                });
                int returnValue = fcLog.showOpenDialog(forceFrame);
                if(returnValue == JFileChooser.APPROVE_OPTION) {
                    logFile = fcLog.getSelectedFile();
                    outputPanel.setText("Log file selected: " + logFile.getName() + "\n");
                    try {
                        gaussianDataIO.setLogFile(logFile);
                        logTextField.setText(logFile.getAbsolutePath());
                        
                        isLOGFound = true;
                        if(isFCHKFound == true && isLOGFound == true) {
                            fileButton.setEnabled(true);
                            fcButton.setEnabled(true);
                        }
                    } catch(FileNotFoundException exp) {
                        exp.printStackTrace();
                        //System.out.println(exp.toString());
                    }
                }
            }
        };
    }
    
    private ActionListener getFCHKButtonAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                //System.out.println("FCHKButton");
                
                fcFCHK.setFileFilter(new javax.swing.filechooser.FileFilter() {

                    @Override
                    public boolean accept(File pathname) {
                        
                        if(pathname.getName().toUpperCase().endsWith(".FCHK") ) {
                            return true;
                        }
                        
                        return false;
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }

                    @Override
                    public String getDescription() {
                        return "Gaussian .fchk files";
                        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    }
                    
                });
                
                int returnValue = fcFCHK.showOpenDialog(forceFrame);
                if(returnValue == JFileChooser.APPROVE_OPTION) {
                    fchkFile = fcFCHK.getSelectedFile();
                    outputPanel.setText("Formatted checkpoint file selected: " + fchkFile.getName() + "\n");
                    try {
                        gaussianDataIO.setFCHKFile(fchkFile);
                        fchkTextField.setText(fchkFile.getAbsolutePath());
                        
                        isFCHKFound = true;
                        if(isFCHKFound == true && isLOGFound == true) {
                            fileButton.setEnabled(true);
                            fcButton.setEnabled(true);
                        }
                    } catch(FileNotFoundException exp) {
                        exp.printStackTrace();
                        //System.out.println(exp.toString());
                    }
                }
            }
        };
    }
    
    private void startAllBondForceConstants() {
        try {
            DetermineMass determineMass = null;
            if(gaussianDataIO.loadForceConstants() == true) {
                List<String> fcLines = gaussianDataIO.getFCLines();
                determineMass = new DetermineMass(logFile, outputPanel);
                double frequencyScalar = getFrequencyScaler();
                buildHessian = new BuildHessian(outputPanel, fcLines, determineMass.getMatrixSize()*3, calculateByMass,frequencyScalar);
                ArrayList<Integer> atomList = determineMass.getAtomList();
                int arraySize = atomList.size();
                
                
                
                double[][] forceConstants = new double[arraySize][arraySize];
                
                for(int i=0; i<arraySize; i++) { //fixed
                    for(int j=0; j<arraySize; j++) { //displaced
                        if(i==j) {
                            forceConstants[i][j] = Double.NaN;
                            continue;
                        }
                        fixedAtom = atomList.get(i);
                        displacedAtomA = atomList.get(j);
                        
                        String[] atomIDs = new String[2];
                        atomIDs[0] = String.valueOf(fixedAtom);
                        atomIDs[1] = String.valueOf(displacedAtomA);
                        
                        distanceCoords = gaussianDataIO.getXYZcoordsBohr(DISTANCE, atomIDs);
                        
                        double massA = determineMass.getMass(fixedAtom);
                        double massB = determineMass.getMass(displacedAtomA);
                        try {
                            forceConstants[i][j] = computeFCDistance(massA, massB);
                        } catch(MathArithmeticException exp) {
                            JOptionPane.showMessageDialog(detailPanel, "Impossible stretch force constant calculation!\nCheck your atom IDs.");
                            return;
                        }
                    }
                }
                
                outputPanel.setText("\n\n-------All Force Constants------\n");
                outputPanel.setText("\n");
                for(int i=0; i<arraySize; i++) { //fixed
                    for(int j=0; j<arraySize; j++) { //displaced
                        outputPanel.setText(forceConstants[i][j] + " ");
                        //System.out.print(forceConstants[i][j] + " ");
                    }
                    outputPanel.setText("\n");
                }
                
                //all the looping goes on in here:
                //double massA = determineMass.getMass(fixedAtom);
                //double massB = determineMass.getMass(displacedAtomA);
                //outputPanel.setText("\nUsing masses: " + massA + " " + massB + "\n");
                //computeFCDistance(massA, massB);
                
            } else {
                JOptionPane.showMessageDialog(forceFrame, "Could not find the FCs after the file was parsed.", "FC error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch(Exception exp) {
            exp.printStackTrace();
        }
    }
    
    /**
     * This is where the derivation of the FCs begin. It is called from the execution of a thread
     * after an actionListener for the "start/calculate" button is executed.
     * 
     * 1) Load in the force constant data (.fchk file).
     * 2) Build the mass weighted hessian.
     * 3) Load in the displacement data (.log file).
     * 4) If this is a distance, then execute: computeFCDistance() (within this class)
     */
    private void startForceConstants() {
        outputPanel.setText("Executing ForceConstant Tool for Amber FF Parameterisation\n\n");
        //GaussianDataIO gaussianDataIO = GaussianDataIO.getInstance();
        
        //File logFile = new File("/Users/acnash/NetBeansProjects/ForceConstants/" + FILE_OUT);
        //File fchkFile = new File("/Users/acnash/NetBeansProjects/ForceConstants/" + FILE_FCHK);
        //try {
        //    gaussianDataIO.setFCHKFile(fchkFile);
        //    gaussianDataIO.setLogFile(logFile);
        //} catch (NullPointerException | FileNotFoundException ex) {
        //    Logger.getLogger(ForceConstants.class.getName()).log(Level.SEVERE, null, ex);
        //    return;
        //}  
        try {
            DetermineMass determineMass = null;
            if(gaussianDataIO.loadForceConstants() == true) {
                List<String> fcLines = gaussianDataIO.getFCLines();
                determineMass = new DetermineMass(logFile, outputPanel);
                //do I instantiate a new hessian per file?
                double frequencyScalar = getFrequencyScaler();
                buildHessian = new BuildHessian(outputPanel, fcLines, determineMass.getMatrixSize()*3, calculateByMass, frequencyScalar);
                //buildHessian.getHessian();
            } else {
                JOptionPane.showMessageDialog(forceFrame, "Could not find the FCs after the file was parsed.", "FC error", JOptionPane.ERROR_MESSAGE);
                //System.out.println("Could not find the FCs after the file was parsed.");
                return;
            }
            if(gaussianDataIO.loadDisplacement(NORMAL_MODE)) {
                //System.out.println("\nSTARTSTARTSTARTSTARTSTART");
                //System.out.println("All data loaded successfuly");
                
                          
                if(selectedAngleDistance == DISTANCE) {
                    if(fixedAtom == displacedAtomA) {
                        JOptionPane.showMessageDialog(forceFrame,"Selected atoms are identical. Cannot derive a bond force constnat.", "Identical atom", JOptionPane.ERROR_MESSAGE);
                    } else {
                    //List<String> dispVector = gaussianDataIO.getDispLines(displacedAtomA);
                    //computeFCDistance(dispVector);
                        
                        double massA = determineMass.getMass(fixedAtom);
                        double massB = determineMass.getMass(displacedAtomA);
                        outputPanel.setText("\nUsing masses: " + massA + " " + massB + "\n");
                        try {
                            computeFCDistance(massA, massB);
                        } catch(MathArithmeticException exp) {
                            JOptionPane.showMessageDialog(detailPanel, "Impossible stretch force constant calculation!\nCheck your atom IDs.");
                            //return;
                        }
                    }
                } else {
                    double massA = determineMass.getMass(displacedAtomA);
                    double massFixed = determineMass.getMass(fixedAtom);
                    double massC = determineMass.getMass(displacedAtomC);
                    
                    outputPanel.setText("\nUsing masses: A:" + massA + " Fixed:" + massFixed + " C:" + massC + "\n");
                    
                    //I need to get the second displacement data.......
                    //List<String> dispVector = gaussianDataIO.getDispLines(displacedAtomA);
                    //computeFCAngle(dispVector);
                    try {
                        computeFCAngle(massA, massFixed, massC);
                    } catch(MathArithmeticException exp) {
                        JOptionPane.showMessageDialog(detailPanel, "Impossible angle force constant calculation!\nCheck your atom IDs.");
                        //return;
                    }
                }
            } else {
                System.out.println("Count not find displacement data.");
            }
                    
        } catch (IOException ex) {
            Logger.getLogger(ForceConstants.class.getName()).log(Level.SEVERE, null, ex);
            //return;
        }
    
    }
    
    //at the moment, dispVector does not contain both atom displacements (only the one, as with the distance). 
    //private void computeFCAngle(List<String> dispVector) {
    private void computeFCAngle(double massA, double massFixed, double massC) throws MathArithmeticException {
        Matrix[] motionMatrix = buildHessian.buildMotionAngleHessian(fixedAtom, massFixed, displacedAtomA, massA, displacedAtomC, massC);
    
        //motionMatrix[0] = motionMatrix[0].times(conversionFactor);
        //motionMatrix[1] = motionMatrix[1].times(conversionFactor);
        
        //motionMatrix[0] = motionMatrix[0].transpose();
        //motionMatrix[1] = motionMatrix[1].transpose();
        
        outputPanel.setText("\n-------Angular Hessian after unit conversion--------\n");
        outputPanel.setText(motionMatrix[0].get(0, 0) + " " + motionMatrix[0].get(0, 1) + " " + motionMatrix[0].get(0, 2) + "\n");
        outputPanel.setText(motionMatrix[0].get(1, 0) + " " + motionMatrix[0].get(1, 1) + " " + motionMatrix[0].get(1, 2) + "\n");
        outputPanel.setText(motionMatrix[0].get(2, 0) + " " + motionMatrix[0].get(2, 1) + " " + motionMatrix[0].get(2, 2) + "\n");
        //System.out.println();
        outputPanel.setText(motionMatrix[1].get(0, 0) + " " + motionMatrix[1].get(0, 1) + " " + motionMatrix[1].get(0, 2) + "\n");
        outputPanel.setText(motionMatrix[1].get(1, 0) + " " + motionMatrix[1].get(1, 1) + " " + motionMatrix[1].get(1, 2) + "\n");
        outputPanel.setText(motionMatrix[1].get(2, 0) + " " + motionMatrix[1].get(2, 1) + " " + motionMatrix[1].get(2, 2) + "\n");
        
        
        //EigenDecomposition edA = new EigenDecomposition(motionMatrix[0]);
        //EigenDecomposition edC = new EigenDecomposition(motionMatrix[1]);
        
        EigenvalueDecomposition jamaEDA = new EigenvalueDecomposition(motionMatrix[0]);
        EigenvalueDecomposition jamaEDC = new EigenvalueDecomposition(motionMatrix[1]);
        
        
        //double[] eigenValuesA = edA.getRealEigenvalues();
        //double[] eigenValuesC = edC.getRealEigenvalues();
        
        double[] eigenValuesA = jamaEDA.getRealEigenvalues();
        double[] eigenValuesC = jamaEDC.getRealEigenvalues();
        
        //eigenValuesA[0] = eigenValuesA[0]*-1;
        //eigenValuesA[1] = eigenValuesA[1]*-1;
        //eigenValuesA[2] = eigenValuesA[2]*-1;
        //eigenValuesC[0] = eigenValuesC[0]*-1;
        //eigenValuesC[1] = eigenValuesC[1]*-1;
        //eigenValuesC[2] = eigenValuesC[2]*-1;
        
        Matrix matrixEigenVectorA = jamaEDA.getV();
        Matrix matrixEigenVectorC = jamaEDC.getV();
        double[][] dataEigenVectorA = matrixEigenVectorA.getArray();
        double[][] dataEigenVectorC = matrixEigenVectorC.getArray();
        
        
        
        RealVector[] eigenVectorA = new RealVector[3];
        RealVector[] eigenVectorC = new RealVector[3];
        for(int i=0; i<3; i++) {
            eigenVectorA[i] = new ArrayRealVector(3);
            eigenVectorA[i].setEntry(0, dataEigenVectorA[i][0]);
            eigenVectorA[i].setEntry(1, dataEigenVectorA[i][1]);
            eigenVectorA[i].setEntry(2, dataEigenVectorA[i][2]);
            eigenVectorC[i] = new ArrayRealVector(3);
            eigenVectorC[i].setEntry(0, dataEigenVectorC[i][0]);
            eigenVectorC[i].setEntry(1, dataEigenVectorC[i][1]);
            eigenVectorC[i].setEntry(2, dataEigenVectorC[i][2]);
        }
        
        //System.out.println("\nFirst eigenvalues");
        //analyseEigenValuesVectors(jamaEDA, eigenValuesA, matrixEigenVectorA);
        //System.out.println("\nSecond eigenvalues");
        //analyseEigenValuesVectors(jamaEDC, eigenValuesC, matrixEigenVectorC);
        
        //RealVector eigenVectorA3 = edA.getEigenvector(2);
        //RealVector eigenVectorC1 = edC.getEigenvector(0);
        //RealVector eigenVectorC2 = edC.getEigenvector(1);
        //RealVector eigenVectorC3 = edC.getEigenvector(2);
        
        double positionA[] = new double[3]; 
        double positionFixed[] = new double[3];
        double positionC[] = new double[3];
        positionA[0] = Double.valueOf(angleCoords[1][0]);
        positionA[1] = Double.valueOf(angleCoords[1][1]);
        positionA[2] = Double.valueOf(angleCoords[1][2]);
        positionFixed[0] = Double.valueOf(angleCoords[0][0]);
        positionFixed[1] = Double.valueOf(angleCoords[0][1]);
        positionFixed[2] = Double.valueOf(angleCoords[0][2]);
        positionC[0] = Double.valueOf(angleCoords[2][0]);
        positionC[1] = Double.valueOf(angleCoords[2][1]);
        positionC[2] = Double.valueOf(angleCoords[2][2]);
        
        
        RealVector positionVectorA = new ArrayRealVector(positionA);
        RealVector positionVectorB = new ArrayRealVector(positionFixed);
        RealVector positionVectorC = new ArrayRealVector(positionC);
        
        //only A and C are meant to move in angle A-B-C
        RealVector unitVectorAB = (positionVectorB.subtract(positionVectorA)).unitVector();
        RealVector unitVectorCB = (positionVectorB.subtract(positionVectorC)).unitVector();
        
        
        Vector3D unitVectorAB3D = new Vector3D(unitVectorAB.getEntry(0),unitVectorAB.getEntry(1),unitVectorAB.getEntry(2));
        Vector3D unitVectorCB3D = new Vector3D(unitVectorCB.getEntry(0),unitVectorCB.getEntry(1),unitVectorCB.getEntry(2));
        
        //get the unit vector perpendicular to the plane ABC
        Vector3D vectorCrossProduct = unitVectorCB3D.crossProduct(unitVectorAB3D);
        
        
        //THIS SEEMS REALLY ODD!!!
        //double bottomDistance = Math.sqrt(Math.pow(vectorCrossProduct.getX(),2) + Math.pow(vectorCrossProduct.getY(),2) + Math.pow(vectorCrossProduct.getZ(),2));
        //Vector3D unitPlaneABC = vectorCrossProduct.scalarMultiply(1/bottomDistance);
        double other = vectorCrossProduct.getNorm();
        Vector3D unitPlaneABC = vectorCrossProduct.scalarMultiply(1/other);
        
        //get the unit vectors perpendicular to the bonds AB and CB on the plane ABC
        Vector3D unitBondPA = unitPlaneABC.crossProduct(unitVectorAB3D);
        Vector3D unitBondPC = unitVectorCB3D.crossProduct(unitPlaneABC);
        
        //then get the bond distance AB and CB
        Vector3D positionAVector = new Vector3D(positionA[0], positionA[1], positionA[2]);
        Vector3D positionBVector = new Vector3D(positionFixed[0], positionFixed[1], positionFixed[2]);
        Vector3D positionCVector = new Vector3D(positionC[0], positionC[1], positionC[2]);
        double bondDistanceAB = positionAVector.distance(positionBVector);
        double bondDistanceCB = positionCVector.distance(positionBVector);
        
        double[] dimsPA = {unitBondPA.getX(), unitBondPA.getY(), unitBondPA.getZ()};
        RealVector rvUnitBondPA = new ArrayRealVector(dimsPA);
        double[] dimsPC = {unitBondPC.getX(), unitBondPC.getY(), unitBondPC.getZ()};
        RealVector rvUnitBondPC = new ArrayRealVector(dimsPC);
        
        double ABPart=0;
        for(int i=0; i<3; i++) {
            //System.out.println(rvUnitBondPA.dotProduct(eigenVectorA[i]));
            ABPart += eigenValuesA[i]*Math.abs(rvUnitBondPA.dotProduct(eigenVectorA[i]));
        }
        ABPart = ABPart*Math.pow(bondDistanceAB,2);
        
        double CBPart=0;
        for(int i=0; i<3; i++) {
            //System.out.println(rvUnitBondPC.dotProduct(eigenVectorC[i]));
            CBPart += eigenValuesC[i]*Math.abs(rvUnitBondPC.dotProduct(eigenVectorC[i]));
        }
        CBPart = CBPart*Math.pow(bondDistanceCB,2);
         
        outputPanel.setText("A-B term: " + (1/ABPart) + "\n");
        outputPanel.setText("C-B term: " + (1/CBPart) + "\n");
        
        double FC = ((1/ABPart) + (1/CBPart));
        System.out.println("FC: " + FC);
        
        
       double rearrangedFC = 1/(2*FC);
        
        //double rearrangedFC = (2*(ABPart*CBPart)/(CBPart+ABPart));
        //double rearrangedFC = 1/FC;
        
        //outputPanel.setText("\nAngular Force constant 1/k = " + FC + "\n");
        outputPanel.setText("\nAngular Force constant k = " + rearrangedFC + " (kcal/mol/rad^2) (AMBER)\n");
        //outputPanel.setText("\nAngular Force constant k = " + (rearrangedFC*4.187) + " (kJ/mol/rad^2) (Gromacs)\n");
        //outputPanel.setText("\nAngular Force constant for radians k = " + rearrangedFC + "\n");
        
        angleAmber = rearrangedFC;
        angleGromacs = (rearrangedFC*4.187);
    }
    
    
    
    /**
     * This is where the force constant for a bond distance is derived. The final value is: (kJ/(mol A^2)),
     * 
     * @param massA
     * @param massB
     * @return 
     */
    private double computeFCDistance(double massA, double massB) throws MathArithmeticException {
        //RealMatrix motionMatrix = buildHessian.buildMotionDistanceHessian(fixedAtom, displacedAtomA);
        Matrix motionMatrix = buildHessian.buildMotionDistanceHessian(fixedAtom, massA, displacedAtomA, massB);
        
        
        //VERY IMPORTANT - COMMENTED OUT TO IMPLEMENT EARLIER IN THE RAW HESSIAN
        //motionMatrix = motionMatrix.times(FCUtils.truncateDecimal(conversionFactor,8).doubleValue());
        
        
        //test the other kind of eigenvector - how do the numbers differ.
//        RealMatrix testMatrix = MatrixUtils.createRealMatrix(motionMatrix.getArray());
//        EigenDecomposition ed = new EigenDecomposition(testMatrix);
//        RealVector rv1 = ed.getEigenvector(0);
//        RealVector rv2 = ed.getEigenvector(1);
//        RealVector rv3 = ed.getEigenvector(2);
//        
//        outputPanel.setText("\nTest Eigen Vectors\n");
//        outputPanel.setText(rv1.getEntry(0) + " " + rv1.getEntry(1) + " " + rv1.getEntry(2) + "\n");
//        outputPanel.setText(rv2.getEntry(0) + " " + rv2.getEntry(1) + " " + rv2.getEntry(2) + "\n");
//        outputPanel.setText(rv3.getEntry(0) + " " + rv3.getEntry(1) + " " + rv3.getEntry(2) + "\n");
        
        EigenvalueDecomposition jamaED = new EigenvalueDecomposition(motionMatrix);
        
        //double[] eigenValues = ed.getRealEigenvalues();
        double[] eigenValues = jamaED.getRealEigenvalues();
        
        //eigenValues[0] = eigenValues[0]*-1;
        //eigenValues[1] = eigenValues[1]*-1;
        //eigenValues[2] = eigenValues[2]*-1;
        
        Matrix eigenVector = jamaED.getV();
        
        //RealVector[] eigenVectors = new RealVector[3];
        //for(int i=0; i<3; i++) {
        //    eigenVectors[0].set(eigenVector.get(0, i));
        //    eigenVectors[1].set(eigenVector.get(1, i));
        //    eigenVectors[2].set(eigenVector.get(2, i));
        //}
        //for(int i=0; i<2; i++) {
        //    eigenVectors[0].setEntry(i, eigenVectors[0].getEntry(i)*-1);
        //}
        //RealVector eigenVectorB = ed.getEigenvector(1);
        //RealVector eigenVectorC = ed.getEigenvector(2);
        
        //fix this....
        //analyseEigenValuesVectors(ed, eigenValues,eigenVectors);
        //analyseEigenValuesVectors(jamaED, eigenValues,eigenVector);
        
        double positionB[] = new double[3]; 
        double positionFixed[] = new double[3];
        //positionB[0] = Double.valueOf(distanceCoords[1][0])*0.529177;
        //positionB[1] = Double.valueOf(distanceCoords[1][1])*0.529177;
        //positionB[2] = Double.valueOf(distanceCoords[1][2])*0.529177;
        //positionFixed[0] = Double.valueOf(distanceCoords[0][0])*0.529177;
        //positionFixed[1] = Double.valueOf(distanceCoords[0][1])*0.529177;
        //positionFixed[2] = Double.valueOf(distanceCoords[0][2])*0.529177;
        
        positionB[0] = Double.valueOf(distanceCoords[1][0]);
        positionB[1] = Double.valueOf(distanceCoords[1][1]);
        positionB[2] = Double.valueOf(distanceCoords[1][2]);
        positionFixed[0] = Double.valueOf(distanceCoords[0][0]);
        positionFixed[1] = Double.valueOf(distanceCoords[0][1]);
        positionFixed[2] = Double.valueOf(distanceCoords[0][2]);
        
        outputPanel.setText("\nFixed positions (x,y,z)\n");
        outputPanel.setText(positionFixed[0] + " " + positionFixed[1] + " " + positionFixed[2] + "\n");
        outputPanel.setText("\nDisplaced positions (x,y,z)\n");
        outputPanel.setText(positionB[0] + " " + positionB[1] + " " + positionB[2] + "\n");
        
        RealVector positionVectorA = new ArrayRealVector(positionFixed);
        RealVector positionVectorB = new ArrayRealVector(positionB);
        
        
        //RealVector normVector = new ArrayRealVector(3);
        
        //This is what I need to check next.
        //RealVector testBminA = positionVectorB.subtract(positionVectorA);
        //RealVector testAminB = positionVectorA.subtract(positionVectorB);
        
        //outputPanel.setText("\n" + testBminA.getEntry(0) + " " + testBminA.getEntry(1) + " " + testBminA.getEntry(2) + "\n");
        //outputPanel.setText(testAminB.getEntry(0) + " " + testAminB.getEntry(1) + " " + testAminB.getEntry(2) + "\n");
        
        //double distanceTest = positionVectorB.getDistance(positionVectorA);
        //outputPanel.setText("\nDistance between atoms: " + distanceTest + "\n");
        
        //double theNorm = (positionVectorB.subtract(positionVectorA)).getNorm();
        //double[] testUnitData = new double[3];
        //testUnitData[0] = (positionVectorB.getEntry(0) - positionVectorA.getEntry(0))/theNorm;
        //testUnitData[1] = (positionVectorB.getEntry(1) - positionVectorA.getEntry(1))/theNorm;
        //testUnitData[2] = (positionVectorB.getEntry(2) - positionVectorA.getEntry(2))/theNorm;
        
        
        //RealVector testUnitVector = MatrixUtils.createRealVector(testUnitData);
        
        //IMPORTANT THIS WAS REMOVED WHILST WORKING WITH TOM
        RealVector unitVector = (positionVectorB.subtract(positionVectorA)).unitVector();
        
        outputPanel.setText("\nUnit Vector:\n");
        outputPanel.setText(unitVector.getEntry(0) + " " + unitVector.getEntry(1) + " " + unitVector.getEntry(2) + "\n");
        
        //outputPanel.setText("\nTesting Unit Vector:\n");
        //outputPanel.setText(testUnitVector.getEntry(0) + " " + testUnitVector.getEntry(1) + " " + testUnitVector.getEntry(2) + "\n");
        
        double FC;
        
        double[][] ev = eigenVector.getArray();
        RealVector[] eigenVectors = new ArrayRealVector[3];
        eigenVectors[0] = new ArrayRealVector(3);
        eigenVectors[1] = new ArrayRealVector(3);
        eigenVectors[2] = new ArrayRealVector(3);
        for(int i=0; i<3; i++) {
            eigenVectors[0].setEntry(i,ev[0][i]);
            eigenVectors[1].setEntry(i,ev[1][i]);
            eigenVectors[2].setEntry(i,ev[2][i]);
        }
        
        //int isOrthogonal = isOrthogonalDistanceSystem(unitVector, eigenVectors[0], eigenVectors[1], eigenVectors[2]);
        //if(isOrthogonal >=0) {
        //    FC = eigenValues[isOrthogonal];
        //} else {
        
        outputPanel.setText("\nEigenVectors\n");
        outputPanel.setText(eigenVectors[0].getEntry(0) + " " + eigenVectors[0].getEntry(1) + " " + eigenVectors[0].getEntry(2) + "\n");
        outputPanel.setText(eigenVectors[1].getEntry(0) + " " + eigenVectors[1].getEntry(1) + " " + eigenVectors[1].getEntry(2) + "\n");
        outputPanel.setText(eigenVectors[2].getEntry(0) + " " + eigenVectors[2].getEntry(1) + " " + eigenVectors[2].getEntry(2) + "\n");
        
        outputPanel.setText("\nEigenValues * dotproducts\n");
        outputPanel.setText(eigenValues[0] + " " +unitVector.dotProduct(eigenVectors[0]) + "\n");
        outputPanel.setText(eigenValues[1] + " " +unitVector.dotProduct(eigenVectors[1]) + "\n");
        outputPanel.setText(eigenValues[2] + " " +unitVector.dotProduct(eigenVectors[2]) + "\n");
        
        
        double A = eigenValues[0] * Math.abs(unitVector.dotProduct(eigenVectors[0]));
        double B = eigenValues[1] * Math.abs(unitVector.dotProduct(eigenVectors[1]));
        double C = eigenValues[2] * Math.abs(unitVector.dotProduct(eigenVectors[2]));
        
        FC = (A + B + C)/2;
            //FC = FC*(ForceConstants.kcalMolConversion*ForceConstants.angstromConversion);
            //FC = FC*conversionFactor;
        //}
        
        //double dampFactor = 1;
        //FC = FC*((1/0.529177249)*(1/0.529177249)*627.502)/2;
        
        //System.out.println("\n---------------------------\nForce constant: " + FC);
        //outputString.concat("\n---------------------------\nForce constant: " + String.valueOf(FC));
        outputPanel.setText("\n---------------------------\nForce constant: " + String.valueOf(FC) + " (kcal/(mol A^2)) (AMBER)\n");
        outputPanel.setText("\n---------------------------\nForce constant: " + String.valueOf(FC*(4.187/0.01)) + " (kJ/(mol nm^2)) (GROMACS)");
        
        distanceAmber = FC;
        distanceGromacs = FC*(4.187/0.01);
        
        return FC;
    }
    
    private int isOrthogonalDistanceSystem(RealVector unitVector, RealVector eigenVectorA, RealVector eigenVectorB, RealVector eigenVectorC) {
        //System.out.println("\nUnitVector :" + unitVector.getEntry(0) + " " + unitVector.getEntry(1) + " " + unitVector.getEntry(2));
        //System.out.println("EigenVector :" + eigenVectorA.getEntry(0) + " " + eigenVectorA.getEntry(1) + " " + eigenVectorA.getEntry(2));
        //System.out.println("EigenVector :" + eigenVectorB.getEntry(0) + " " + eigenVectorB.getEntry(1) + " " + eigenVectorB.getEntry(2));
        //System.out.println("EigenVector :" + eigenVectorC.getEntry(0) + " " + eigenVectorC.getEntry(1) + " " + eigenVectorC.getEntry(2));
        
        //if an eigenvector is in the same direction as the unitVector which describes the direction of A to B
        //AND
        //that eigenVector forms an orthogonal system with the two other eigenVectors
        //USE
        //FC = the respective eigenValue
        
        if (eigenVectorA == unitVector || eigenVectorB == unitVector || eigenVectorC == unitVector ){
            if(eigenVectorA == unitVector && (eigenVectorA.dotProduct(eigenVectorB) == 0 && eigenVectorA.dotProduct(eigenVectorC) == 0)) {
                return 0;
            }
            if(eigenVectorB == unitVector && (eigenVectorB.dotProduct(eigenVectorB) == 0 && eigenVectorB.dotProduct(eigenVectorC) == 0)) {
                return 1;
            }
            if(eigenVectorC == unitVector && (eigenVectorC.dotProduct(eigenVectorB) == 0 && eigenVectorC.dotProduct(eigenVectorC) == 0)) {
                return 2;
            }
        } 
        
        
        return -1;
    }
    
    //private void analyseEigenValuesVectors(EigenvalueDecomposition ed, double[] eigenValues, RealVector[] eigenVector) {
    private void analyseEigenValuesVectors(EigenvalueDecomposition ed, double[] eigenValues, Matrix eigenVector) {    
        //double deter = ed.getDeterminant();
        //System.out.println("Determinant");
        //System.out.println(deter);
        
        //System.out.println("Eigenvectors:");
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++) {
        //        System.out.print(eigenVector.get(i, j) + " ");
            }
        //    System.out.println();
        }
        //System.out.println(eigenVector.toString());
        //System.out.println(eigenVector[0]);
        //System.out.println(eigenVector[1]);
        //System.out.println(eigenVector[2]);
        
        double[] imagValues = ed.getImagEigenvalues();
        //if(ed.hasComplexEigenvalues()==true && imagValues.length >= 2) {
        //if(imagValues.length >= 2) {
        //    System.out.println("\nComplex eigenvalues detected.");           
        //    for(int i=0; i<imagValues.length; i++) {
        //        System.out.println(imagValues[i]);
        //    }
        //    System.out.println("Complex eigenValues: Selected atoms will not feel a restoring reaction force. This typically means they are not bonded.");
        //} else {        
            //if any of the eigen values are negative then they will not have a restoring force eithr
            int negCount = 0;
            for(int i=0;i<eigenValues.length; i++) {
                if(eigenValues[i] < 0) {
                    negCount++;
                }
            }
            if(negCount > 0) {
                System.out.println("Negative eigenvalues: Selected atoms will not feel a restoring reaction force. This typically means they are not bonded.");
            }
        //    System.out.println("Eigenvaules");
        //    System.out.println(eigenValues[0]);
        //    System.out.println(eigenValues[1]);
        //    System.out.println(eigenValues[2]);
        //    System.out.println();
        //}
        
        
        //RealVector eigenVectorA = ed.getEigenvector(0);
        //eigenVectorA.setEntry(0, eigenVectorA.getEntry(0)*-1);
        //eigenVectorA.setEntry(1, eigenVectorA.getEntry(1)*-1);
        //eigenVectorA.setEntry(2, eigenVectorA.getEntry(2)*-1);
        
        //RealVector eigenVectorB = ed.getEigenvector(1);
        //eigenVectorB.setEntry(0, eigenVectorB.getEntry(0)*-1);
        //eigenVectorB.setEntry(1, eigenVectorB.getEntry(1)*-1);
        //eigenVectorB.setEntry(2, eigenVectorB.getEntry(2)*-1);
        
        //RealVector eigenVectorC = ed.getEigenvector(2);
        //eigenVectorC.setEntry(0, eigenVectorC.getEntry(0)*-1);
        //eigenVectorC.setEntry(1, eigenVectorC.getEntry(1)*-1);
        //eigenVectorC.setEntry(2, eigenVectorC.getEntry(2)*-1);
        
        //System.out.println("\nEigen Vectors");
        //System.out.println(eigenVectorA.getEntry(0) + " " + eigenVectorA.getEntry(1) + " " + eigenVectorA.getEntry(2));
        //System.out.println(eigenVectorB.getEntry(0) + " " + eigenVectorB.getEntry(1) + " " + eigenVectorB.getEntry(2));
        //System.out.println(eigenVectorC.getEntry(0) + " " + eigenVectorC.getEntry(1) + " " + eigenVectorC.getEntry(2));
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ForceConstants fc = new ForceConstants();
    }

    private double getFrequencyScaler() {
        String strValue = this.scalarTextField.getText();
        if(strValue.isEmpty()) {
            strValue = "0.8929";
        }
        
        return Double.valueOf(strValue);
    }
    
    
}
