/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package forceconstants;

import java.math.BigDecimal;
import org.apache.commons.math3.*;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;

/**
 *
 * @author acnash
 */
public class FCUtils {
   
    public static BigDecimal truncateDecimal(double x,int numberofDecimals) {

        if ( x > 0) {
            return new BigDecimal(String.valueOf(x)).setScale(numberofDecimals, BigDecimal.ROUND_FLOOR);
        } else {
            return new BigDecimal(String.valueOf(x)).setScale(numberofDecimals, BigDecimal.ROUND_CEILING);
        }
    }
    
    /**
     * 
     * @param angleCoords [0][*] fixed atom, [1][*] displaced atom A, [2][*] displaced atom C
     * @return 
     */
    public static double determineAngle(String[][] angleCoords) {
        double x0 = Double.valueOf(angleCoords[0][0]);
        double y0 = Double.valueOf(angleCoords[0][1]);
        double z0 = Double.valueOf(angleCoords[0][2]);
        
        double x1 = Double.valueOf(angleCoords[1][0]);
        double y1 = Double.valueOf(angleCoords[1][1]);
        double z1 = Double.valueOf(angleCoords[1][2]);
        double x2 = Double.valueOf(angleCoords[2][0]);
        double y2 = Double.valueOf(angleCoords[2][1]);
        double z2 = Double.valueOf(angleCoords[2][2]);
        
        double ux= x1-x0;
        double uy= y1-y0;
        double uz= z1-z0;
        
        double vx= x2-x0;
        double vy= y2-y0;
        double vz= z2-z0;
        
        double lengthU = Math.sqrt(Math.pow(ux, 2)+Math.pow(uy, 2)+Math.pow(uz, 2));
        double lengthV = Math.sqrt(Math.pow(vx, 2)+Math.pow(vy, 2)+Math.pow(vz, 2));
        
        double denominator = lengthU*lengthV;
        double numerator = (ux*vx) + (uy*vy) + (uz*vz);
        
        double cosineRule = numerator/denominator;
        double angle = Math.acos(cosineRule);
        
        return angle;
    }
    
    /**
     * 
     * @param lengthCoords [0][*] fixed atom, [1][*] displaced atom
     * @return 
     */
    public static double determineBondLength(String[][] lengthCoords) {
        double[] positionA = new double[3];
        double[] positionB = new double[3];
        positionA[0] = Double.valueOf(lengthCoords[0][0]);
        positionA[1] = Double.valueOf(lengthCoords[0][1]);
        positionA[2] = Double.valueOf(lengthCoords[0][2]);
        positionB[0] = Double.valueOf(lengthCoords[1][0]);
        positionB[1] = Double.valueOf(lengthCoords[1][1]);
        positionB[2] = Double.valueOf(lengthCoords[1][2]);
        
        RealVector vectorA = new ArrayRealVector(positionA);
        RealVector vectorB = new ArrayRealVector(positionB);
        double length = vectorB.getDistance(vectorA);
        
        
        
//        double x0 = Double.valueOf(lengthCoords[0][0]);
//        double y0 = Double.valueOf(lengthCoords[0][1]);
//        double z0 = Double.valueOf(lengthCoords[0][2]);
//        double x1 = Double.valueOf(lengthCoords[1][0]);
//        double y1 = Double.valueOf(lengthCoords[1][1]);
//        double z1 = Double.valueOf(lengthCoords[1][2]);
//        
//        double A = Math.pow(x1-x0, 2);
//        double B = Math.pow(y1-y0, 2);
//        double C = Math.pow(z1-z0, 2);
//        
//        double length = Math.sqrt(A+B+C);
        
        return length;
    }
}
