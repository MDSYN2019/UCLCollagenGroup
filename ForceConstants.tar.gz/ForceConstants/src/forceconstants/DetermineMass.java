/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package forceconstants;

import ForceView.OutputPanel;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import javax.swing.JOptionPane;

/**
 *
 * @author acnash
 */
public class DetermineMass {
    
    private ArrayList<Double> weightList = new ArrayList<Double>();
    private OutputPanel outputPanel = null;
    private ArrayList<Integer> atomList = new ArrayList<Integer>();
    
    public DetermineMass(File outputFile, OutputPanel outputPanel) throws IOException {
        this.outputPanel = outputPanel;
        List<String> lines = Files.readAllLines(outputFile.toPath());
        ListIterator<String> listIterator = lines.listIterator();
        //String coordLine = null;
        boolean completed = false;
        while(listIterator.hasNext()) {
            String line = listIterator.next();
            
            
            //if(line.contains("Input orientation")) {
            if(line.contains("Standard orientation")){
                //Go through the header data,
                //System.out.println("Test");
                for(int i=0; i<4; i++) {
                    line = listIterator.next();
                }
                while(listIterator.hasNext()) {
                    String massLine = listIterator.next();
                    if(massLine.contains("---------")) {
                        completed = true;
                        break;
                    } else {
                        String[] splitString = massLine.split("\\s+");
                        String atomicNumber = splitString[2];
                        atomList.add(Integer.valueOf(splitString[1]));
                        assignMass(Integer.valueOf(atomicNumber));
                    }
                }
                
            }
            if(completed == true) {
                break;
            }
            
        }
        
        //String[] splitString = coordLine.split("\\s+");
        
    }
    
    public int getMatrixSize() {
        return weightList.size();
    }
    
    private void assignMass(int atomicNumber) {
        switch(atomicNumber) {
            case 1: //hydrogen
                weightList.add(1.008);
                break;
            case 2:
                weightList.add(4.003);
                break;
            case 3:
                weightList.add(6.941);
                break;
            case 4:
                weightList.add(9.012);
                break;
            case 5:
                weightList.add(10.811);
                break;
            case 6:
                weightList.add(12.011);
                break;
            case 7:
                weightList.add(14.007);
                break;
            case 8:
                weightList.add(15.999);
                break;
            case 9:
                weightList.add(18.998);
                break;
            case 10:
                weightList.add(20.180);
                break;
            case 11:
                weightList.add(22.990);
                break;
            case 12:
                weightList.add(24.305);
                break;
            case 13:
                weightList.add(26.982);
                break;
            case 14:
                weightList.add(28.086);
                break;
            case 15:
                weightList.add(30.974);
                break;
            case 16:
                weightList.add(32.066);
                break;
            case 17:
                weightList.add(35.435);
                break;
            case 18:
                weightList.add(39.948);
                break;
            case 19:
                weightList.add(39.098);
                break;
            case 20:
                weightList.add(40.078);
                break;
            case 21:
                weightList.add(44.956);
                break;
            case 22:
                weightList.add(47.88);
                break;
            case 23:
                weightList.add(50.942);
                break;
            case 24:
                weightList.add(51.996);
                break;
            case 25:
                weightList.add(54.938);
                break;
            case 26:
                weightList.add(55.933);
                break;
            case 27:
                weightList.add(58.933);
                break;
            case 28:
                weightList.add(58.693);
                break;
            case 29:
                weightList.add(63.546);
                break;
            case 30:
                weightList.add(65.39);
                break;
            case 31:
                weightList.add(69.732);
                break;
            case 32:
                weightList.add(72.61);
                break;
            case 33:
                weightList.add(74.922);
                break;
            case 34:
                weightList.add(78.09);
                break;
            case 35:
                weightList.add(79.904);
                break;
            default: 
                JOptionPane.showMessageDialog(outputPanel, "Unrecognised atom centre: " + atomicNumber, "Mass weighted hessian error.", JOptionPane.ERROR_MESSAGE);
                //System.out.println("Unrecognised atom centre: " + atomicNumber );
        }
    }
    
    public double getMass(int atomID) {
        return weightList.get(atomID-1);
    }
    
    public ArrayList<Integer> getAtomList() {
        return atomList;
    }
    
}
