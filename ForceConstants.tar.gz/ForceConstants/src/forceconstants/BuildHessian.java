/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package forceconstants;

import ForceView.OutputPanel;
import Jama.Matrix;
import java.util.*;
import org.apache.commons.math3.linear.*;


/**
 *
 * @author acnash
 */
public class BuildHessian {

    private OutputPanel outputPanel = null;
    private int matrixSize;
    private RealMatrix hessian = null;
    private boolean calculateMassWeight = true;
    
    public BuildHessian(OutputPanel outputPanel, List<String> fcData, int matrixSize, boolean calculateMassWeight, double frequencyScalar) {
        this.matrixSize = matrixSize;
        this.outputPanel = outputPanel;
        this.calculateMassWeight = calculateMassWeight;
        hessian = MatrixUtils.createRealMatrix(matrixSize, matrixSize);

        List<Double> dataList = new ArrayList<>();
        ListIterator it = fcData.listIterator();
        int i=0;
        while(it.hasNext()) {
            String line = (String)it.next();
            StringTokenizer tc = new StringTokenizer(line);
            while(tc.hasMoreElements()) {
                i++;
                String entry = tc.nextToken();
                Double dObj = new Double(entry);
                dataList.add(dObj);              
            }
            
        }
        
        outputPanel.setText("\nFound " + i + " Hessian entries.");
        outputPanel.setText("\nMatrix size: " + matrixSize);
        
        int count = 0;
        for(int k=0; k<=matrixSize; k++) {
            for(int j=0; j<k; j++) {
                Double dObj = dataList.get(count);
                hessian.addToEntry(j,(k-1), dObj);
                count++;
            }
        }
        
        
        //BUILDING THE HESSIAN MATRIX FROM SYMMETRIC HESSIAN MATRIX
        for(int k=0; k<matrixSize; k++) { //row
            for(int j=1; j<matrixSize; j++) { //column
                double entry = hessian.getEntry(k, j);
                hessian.setEntry(j,k,entry); 
            }
        }
        
        
        outputPanel.setText("\n----Full Hessian------\n");
        for(int k=0; k<matrixSize; k++) {
            for(int j=0; j<matrixSize; j++) {
                outputPanel.setText(hessian.getEntry(k, j) + " ");
            }
            outputPanel.setText("\n");
        }
        
        try {
            MatrixUtils.checkSymmetric(hessian, 0.1);
        } catch(NonSymmetricMatrixException exp) {
            exp.printStackTrace();
        }
        
        
        outputPanel.setText("Scaling frequencies by " + frequencyScalar + "\n");
        hessian = hessian.scalarMultiply(frequencyScalar); 
        
        if(ForceConstants.selectedAngleDistance == ForceConstants.DISTANCE) {
            hessian = hessian.scalarMultiply(ForceConstants.conversion);
            outputPanel.setText("Converting to kcal/(mol Ang^2)\n");
        } else {
            outputPanel.setText("Converting to kcal/(mol rad^2)\n");
            hessian = hessian.scalarMultiply(ForceConstants.hartree_to_kcalmol);
        }
        
    }
    
    
    
    public RealMatrix getHessian() {
        return hessian;
    }
    
    //looking for Hessians AB and CB
    public Matrix[] buildMotionAngleHessian(int fixedAtom, double fixedMass, int atomA, double massA, int atomC, double massC) {
        Matrix[] angleHessians = new Matrix[2];  
        angleHessians[0] = new Matrix(3,3);
        angleHessians[1] = new Matrix(3,3);
        
        
        int fixedAtomPosition = (fixedAtom*3)-3; //essentially B in A-B-C
        int atomAPosition = (atomA*3)-3;
        int atomCPosition = (atomC*3)-3;
        
        
        double[][] massesA = new double[matrixSize][matrixSize];
        double[][] massesC = new double[matrixSize][matrixSize];
        for(int i=0; i<matrixSize; i++) {
            for(int j=0; j<matrixSize; j++) {
                if(i==j) {
                    massesA[i][j] = 1/Math.sqrt(massA);
                    massesC[i][j] = 1/Math.sqrt(massC);
                } else {
                    massesA[i][j] = 0;
                    massesC[i][j] = 0;
                }
            }
        }
        RealMatrix massAMatrix  = MatrixUtils.createRealMatrix(massesA);
        RealMatrix massCMatrix  = MatrixUtils.createRealMatrix(massesC);
        
        outputPanel.setText("\nGenerating mass weighted hessian matrix\n");
        RealMatrix mulMatrix;
        if(calculateMassWeight == true) {
            mulMatrix = (massAMatrix.multiply(hessian)).multiply(massCMatrix);
            outputPanel.setText("\nGenerating mass weighted hessian matrix\n");
        } else {
            mulMatrix = hessian;
            outputPanel.setText("\nNot using the mass weighted hessian matrix\n");
        }
        mulMatrix = mulMatrix.scalarMultiply(-1);
        
        for(int k=0; k<matrixSize; k++) { //row
            for(int j=0; j<matrixSize; j++) {//column
                outputPanel.setText(mulMatrix.getEntry(k, j) + " ");
            }
            outputPanel.setText("\n");
        }
        
        angleHessians[0].set(0, 0, mulMatrix.getEntry(fixedAtomPosition, atomAPosition));
        angleHessians[0].set(0, 1, mulMatrix.getEntry(fixedAtomPosition, atomAPosition+1));
        angleHessians[0].set(0, 2, mulMatrix.getEntry(fixedAtomPosition, atomAPosition+2));
        
        angleHessians[0].set(1, 0, mulMatrix.getEntry(fixedAtomPosition+1, atomAPosition));
        angleHessians[0].set(1, 1, mulMatrix.getEntry(fixedAtomPosition+1, atomAPosition+1));
        angleHessians[0].set(1, 2, mulMatrix.getEntry(fixedAtomPosition+1, atomAPosition+2));
        
        angleHessians[0].set(2, 0, mulMatrix.getEntry(fixedAtomPosition+2, atomAPosition));
        angleHessians[0].set(2, 1, mulMatrix.getEntry(fixedAtomPosition+2, atomAPosition+1));
        angleHessians[0].set(2, 2, mulMatrix.getEntry(fixedAtomPosition+2, atomAPosition+2));
        
        
        
        angleHessians[1].set(0, 0, mulMatrix.getEntry(fixedAtomPosition, atomCPosition));
        angleHessians[1].set(0, 1, mulMatrix.getEntry(fixedAtomPosition, atomCPosition+1));
        angleHessians[1].set(0, 2, mulMatrix.getEntry(fixedAtomPosition, atomCPosition+2));
        
        angleHessians[1].set(1, 0, mulMatrix.getEntry(fixedAtomPosition+1, atomCPosition));
        angleHessians[1].set(1, 1, mulMatrix.getEntry(fixedAtomPosition+1, atomCPosition+1));
        angleHessians[1].set(1, 2, mulMatrix.getEntry(fixedAtomPosition+1, atomCPosition+2));
        
        angleHessians[1].set(2, 0, mulMatrix.getEntry(fixedAtomPosition+2, atomCPosition));
        angleHessians[1].set(2, 1, mulMatrix.getEntry(fixedAtomPosition+2, atomCPosition+1));
        angleHessians[1].set(2, 2, mulMatrix.getEntry(fixedAtomPosition+2, atomCPosition+2));
        
        outputPanel.setText("\n-------AngularHessian--------\n");
        outputPanel.setText(angleHessians[0].get(0, 0) + " " + angleHessians[0].get(0, 1) + " " + angleHessians[0].get(0, 2) + "\n");
        outputPanel.setText(angleHessians[0].get(1, 0) + " " + angleHessians[0].get(1, 1) + " " + angleHessians[0].get(1, 2) + "\n");
        outputPanel.setText(angleHessians[0].get(2, 0) + " " + angleHessians[0].get(2, 1) + " " + angleHessians[0].get(2, 2) + "\n");
        outputPanel.setText("\n");
        outputPanel.setText(angleHessians[1].get(0, 0) + " " + angleHessians[1].get(0, 1) + " " + angleHessians[1].get(0, 2) + "\n");
        outputPanel.setText(angleHessians[1].get(1, 0) + " " + angleHessians[1].get(1, 1) + " " + angleHessians[1].get(1, 2) + "\n");
        outputPanel.setText(angleHessians[1].get(2, 0) + " " + angleHessians[1].get(2, 1) + " " + angleHessians[1].get(2, 2) + "\n");
        
        
        return angleHessians;
    }
    
  
    public Matrix buildMotionDistanceHessian(int atomA, double massA, int atomB, double massB) {  
        if(atomA > atomB) {
            int tempAtom = atomA; 
            atomA = atomB;
            atomB = tempAtom;
            //flip = true;
        }
        
        if(MatrixUtils.isSymmetric(hessian, 0.00001) == false) {
            outputPanel.setText("The hessian is not symmetric\n");
        }
        
        double[][] massesA = new double[matrixSize][matrixSize];
        double[][] massesB = new double[matrixSize][matrixSize];
        for(int i=0; i<matrixSize; i++) {
            for(int j=0; j<matrixSize; j++) {
                if(i==j) {
                    massesA[i][j] = 1/Math.sqrt(massA);
                    massesB[i][j] = 1/Math.sqrt(massB);
                } else {
                    massesA[i][j] = 0;
                    massesB[i][j] = 0;
                }
            }
        }
        RealMatrix massAMatrix  = MatrixUtils.createRealMatrix(massesA);
        RealMatrix massBMatrix  = MatrixUtils.createRealMatrix(massesB);
        
        
        RealMatrix mulMatrix;
        if(calculateMassWeight == true) {
            mulMatrix = (massAMatrix.multiply(hessian)).multiply(massBMatrix);
            outputPanel.setText("\nGenerating mass weighted hessian matrix\n");
        } else {
            mulMatrix = hessian;
            outputPanel.setText("\nNot using the mass weighted hessian matrix\n");
        }
        
        
        mulMatrix = mulMatrix.scalarMultiply(-1);
        if(MatrixUtils.isSymmetric(mulMatrix, 0.00001) == false) {
            outputPanel.setText("The mass weighted hessian is not symmetric\n");
        }
       
        
        
        for(int k=0; k<matrixSize; k++) { //row
            for(int j=0; j<matrixSize; j++) {//column
                outputPanel.setText(mulMatrix.getEntry(k, j) + " ");
            }
            outputPanel.setText("\n");
        }
        
        
        Matrix motionHessian = new Matrix(3,3);
        
        
        int atomA_position = (atomA*3)-3;
        int atomB_position = (atomB*3)-3;
        
        
        motionHessian.set(0, 0, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position, atomB_position),8).doubleValue());
        motionHessian.set(0, 1, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position, atomB_position+1),8).doubleValue());
        motionHessian.set(0, 2, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position, atomB_position+2),8).doubleValue());
        
        motionHessian.set(1, 0, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position+1, atomB_position),8).doubleValue());
        motionHessian.set(1, 1, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position+1, atomB_position+1),8).doubleValue());
        motionHessian.set(1, 2, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position+1, atomB_position+2),8).doubleValue());
        
        motionHessian.set(2, 0, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position+2, atomB_position),8).doubleValue());
        motionHessian.set(2, 1, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position+2, atomB_position+1),8).doubleValue());
        motionHessian.set(2, 2, FCUtils.truncateDecimal(mulMatrix.getEntry(atomA_position+2, atomB_position+2),8).doubleValue());
        
        outputPanel.setText("\n-------motionHessian--------\n");
        outputPanel.setText(motionHessian.get(0, 0) + " " + motionHessian.get(0, 1) + " " + motionHessian.get(0, 2) + "\n");
        outputPanel.setText(motionHessian.get(1, 0) + " " + motionHessian.get(1, 1) + " " + motionHessian.get(1, 2) + "\n");
        outputPanel.setText(motionHessian.get(2, 0) + " " + motionHessian.get(2, 1) + " " + motionHessian.get(2, 2) + "\n");
        
        return motionHessian; 
    }
    
}
