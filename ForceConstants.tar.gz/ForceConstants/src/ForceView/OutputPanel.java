/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneLayout;
import javax.swing.text.DefaultCaret;

/**
 *
 * @author acnash
 */
public class OutputPanel extends JTextPane {//JPanel {
    
    private int historyCount = 0;
    //private JTextPane textPane = new JTextPane();
    //private JTextPane textPane = new JTextPane();
    private String text = new String("");
    
    public OutputPanel() {
        DefaultCaret caret = (DefaultCaret)super.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        
        
        //this.setLayout(new BorderLayout());
        
        //FlowLayout layout = new FlowLayout();
        //layout.setAlignment(FlowLayout.LEFT);
        //this.setLayout(layout);
        //this.setBorder(BorderFactory.createLineBorder(Color.blue));
        
        //textPane.setText("Hello");
        
        //this.add(new JScrollPane(textPane));
        
        //this.add(scrollPane,BorderLayout.CENTER);
    }
    
    public void setText(String moreText) {
        if(historyCount == 3000) {
            text = new String("");
            historyCount = 0;
        }
        String newString = text.concat(moreText);
        //textPane.setText(newString);
        //super.setText(newString);
        text = newString;
        historyCount++;
    }
    
    public void updateText() {
        super.setText(text);
        
    }
    
    //public String getText() {
    //    return text;
    //}
    
}
