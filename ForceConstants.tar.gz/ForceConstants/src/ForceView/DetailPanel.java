/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import forceconstants.ForceConstants;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author acnash
 */
public class DetailPanel extends JPanel {
    
    private final JPanel angleStretchPanel = new JPanel();
    private final JLabel xFixedLabel = new JLabel("Fixed X: ");
    private final JLabel yFixedLabel = new JLabel("Y: ");
    private final JLabel zFixedLabel = new JLabel("Z: ");
    private final JLabel xALabel = new JLabel("Atom A X: ");
    private final JLabel yALabel = new JLabel("Y: ");
    private final JLabel zALabel = new JLabel("Z: ");
    private final JLabel xCLabel = new JLabel("Atom C X: ");
    private final JLabel yCLabel = new JLabel("Y: ");
    private final JLabel zCLabel = new JLabel("Z: ");
    
    private final JTextField scalarField;
    
    public DetailPanel(JPanel starterPanel, JComboBox combo, JButton fullButton, JCheckBox weightCheckBox, JTextField scalarField) {
        this.setBorder(BorderFactory.createLoweredSoftBevelBorder());
        this.setLayout(new BorderLayout());
        GridLayout layout = new GridLayout(2,1);
        //layout.setVgap(1);
        
        JPanel innerPanel = new JPanel(layout);
        
        angleStretchPanel.setBorder(BorderFactory.createEtchedBorder());
        angleStretchPanel.setLayout(new GridLayout(3,1));
        angleStretchPanel.add(combo);
        angleStretchPanel.add(starterPanel);
        angleStretchPanel.add(fullButton, BorderLayout.SOUTH);
        
//        JPanel coordFixedPanel = new JPanel();
//        coordFixedPanel.add(xFixedLabel);
//        coordFixedPanel.add(yFixedLabel);
//        coordFixedPanel.add(zFixedLabel);
//        JPanel coordAPanel = new JPanel();
//        coordAPanel.add(xALabel);
//        coordAPanel.add(yALabel);
//        coordAPanel.add(zALabel);
//        JPanel coordCPanel = new JPanel();
//        coordCPanel.add(xCLabel);
//        coordCPanel.add(yCLabel);
//        coordCPanel.add(zCLabel);
//        
//        JPanel coordPanel = new JPanel(new GridLayout(3,1));
//        coordPanel.add(coordFixedPanel);
//        coordPanel.add(coordAPanel);
//        coordPanel.add(coordCPanel);
        
        this.scalarField = scalarField;
        JPanel checkBoxPanel = new JPanel(new GridLayout(3,1));
        checkBoxPanel.add(weightCheckBox);
        checkBoxPanel.add(new JLabel("Frequency scalar:"));
        checkBoxPanel.add(scalarField);
        
        
        innerPanel.add(angleStretchPanel);
        innerPanel.add(checkBoxPanel);
        this.add(innerPanel,BorderLayout.NORTH);
        //this.add(angleStretchPanel);
        //this.add(checkBoxPanel);
        
        
    }
    
    public void setCoords(String[][] coords, int angleDistance) {
        xFixedLabel.setText("Fixed X: " + coords[0][0]);
        yFixedLabel.setText("Y: " + coords[0][1]);
        zFixedLabel.setText("Z: " + coords[0][2]);
        
        xALabel.setText("Atom A X: " + coords[1][0]);
        yALabel.setText("Y: " + coords[1][1]);
        zALabel.setText("Z: " + coords[1][2]);
        
        if(angleDistance == ForceConstants.ANGLE) {
            xCLabel.setText("Atom A X: " + coords[2][0]);
            yCLabel.setText("Y: " + coords[2][1]);
            zCLabel.setText("Z: " + coords[2][2]);
        } else {
            xCLabel.setText("");
            yCLabel.setText("");
            zCLabel.setText("");
        }
    }
    
    public void addDistanceAnglePanel(JPanel panel) {
        angleStretchPanel.add(panel);
        panel.updateUI();
    }
    
    
    public void removeExistingPanel(Component comp) {
        angleStretchPanel.remove(comp);
        angleStretchPanel.updateUI();
    }
    
    
}
