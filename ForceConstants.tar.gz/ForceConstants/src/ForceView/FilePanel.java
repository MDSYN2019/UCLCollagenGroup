/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author acnash
 */
public class FilePanel extends JPanel {
    
    private JButton fchkButton = null;
    private JButton logButton = null;
    private JTextField fchkTextField = null;
    private JTextField logTextField = null;
    
    public FilePanel() {
        this.setBorder(BorderFactory.createLoweredSoftBevelBorder());
    }
    
    public void setupGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new GridLayout(2,1));
        JPanel textPanel = new JPanel(new GridLayout(2,1));
        
        buttonPanel.add(fchkButton);
        buttonPanel.add(logButton);
        textPanel.add(fchkTextField);
        textPanel.add(logTextField);
        
        mainPanel.add(buttonPanel,BorderLayout.WEST);
        mainPanel.add(textPanel,BorderLayout.CENTER);
        this.add(mainPanel);
        
    }
    
    public void setLOGTextField(JTextField logTextField) {
        this.logTextField = logTextField;
    }
    
    public void setFCHKTextField(JTextField fchkTextField) {
        this.fchkTextField = fchkTextField;
    }
    
    public void setLOGTextFieldAL(ActionListener al) {
        logTextField.addActionListener(al);
    }
    
    public void setFCHKTextFieldAL(ActionListener al) {
        fchkTextField.addActionListener(al);
    }
    
    public void setFCHKFileButton(JButton fchkButton) {
        this.fchkButton = fchkButton;
    }
    
    public void setLOGFileButton(JButton logButton) {
        this.logButton = logButton;
    }
    
    public void setLOGButtonAL(ActionListener al) {
        this.logButton.addActionListener(al);
    }
    
    public void setFCHKButtonAL(ActionListener al) {
        this.fchkButton.addActionListener(al);
    }
   
}
