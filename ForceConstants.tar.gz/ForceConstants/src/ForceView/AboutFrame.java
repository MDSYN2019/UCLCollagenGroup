/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author acnash
 */
public class AboutFrame extends JFrame {
    
    private static final int HEIGHT = 225;
    private static final int WIDTH = 250;
    private final JButton closeButton;
    private final JPanel descriptionPanel = new JPanel();
    private final JTextPane textPane = new JTextPane();
    
    public AboutFrame(JButton closeButton) {
        this.closeButton = closeButton;
        this.setUndecorated(true);
        this.setAlwaysOnTop(true);
        this.setSize(AboutFrame.WIDTH, AboutFrame.HEIGHT);
        centreFrame();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        AboutFrame.setDefaultLookAndFeelDecorated(true);
        this.setResizable(false);
        
        BorderLayout layout = new BorderLayout();
        this.setLayout(layout);
        textPane.setContentType("text/html");
        textPane.setText(getAboutDescription());
        textPane.setEditable(false);
        
        descriptionPanel.setLayout(new BorderLayout());
        descriptionPanel.add(textPane,BorderLayout.CENTER);
        
        this.add(closeButton,BorderLayout.SOUTH);
        this.add(descriptionPanel,BorderLayout.CENTER);
        
        super.setVisible(false);
    }
    
    public void setVisible(boolean isVisible) {
        super.setVisible(isVisible);
    }
    
    private String getAboutDescription() {
        StringBuilder htmlBuilder = new StringBuilder();
        htmlBuilder.append("<html>");
        htmlBuilder.append("<body><p><center><b>Second order tensor force constant parameteriser</b></center></p>");
        htmlBuilder.append("<p>Version: 0.1 - 2016</p>");
        htmlBuilder.append("<p>Anthony Nash - a.nash@ucl.ac.uk</p>");
        htmlBuilder.append("<p>Thomas Collier</p>");
        htmlBuilder.append("<p>Department of Chemistry</p><p>University College London</p>");
        htmlBuilder.append("</body></html>");
        String html = htmlBuilder.toString();
        return html;
    }
    
    private void centreFrame() {
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int width = this.getWidth();
        int height = this.getHeight();
        int x = (dimension.width - width)/2;
        int y = (dimension.height - height)/2;
        this.setLocation(x, y);
                
        //I love Johanna
    }
    
}
