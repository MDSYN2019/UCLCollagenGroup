/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author acnash
 */
public class ForceFrame extends JFrame {
   
    private final JMenuBar menuBar;
    private final JMenu mainMenu;
    private final JMenuItem aboutItem;
    private final JMenuItem instructionItem;
    private final JMenuItem closeItem;
    
    private Image image;
    
    private AboutFrame aboutFrame = null;// = new AboutFrame();
    private InstructionFrame instructionFrame = null;
    
    public ForceFrame() {
        super("Second order tensor force constant parameteriser - Ver 0.7");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ForceFrame.setDefaultLookAndFeelDecorated(true);
        this.setResizable(false);
        
        
        menuBar = new JMenuBar();
        mainMenu = new JMenu("Force constants");
        menuBar.add(mainMenu);
        aboutItem = new JMenuItem("About");
        instructionItem = new JMenuItem("Instructions");
        mainMenu.add(instructionItem);
        mainMenu.add(aboutItem);
        instructionItem.addActionListener(getInstructionAL());
        aboutItem.addActionListener(getAboutAL());
        this.setJMenuBar(menuBar);
        
        JButton closeButton = new JButton("Close");
        aboutFrame = new AboutFrame(closeButton);
        closeButton.addActionListener(getCloseAL());
        
        instructionFrame = new InstructionFrame();
        mainMenu.addSeparator();
        closeItem = new JMenuItem("Close");
        closeItem.addActionListener(getExitButtonAL());
        mainMenu.add(closeItem);
        
    }
    
    private ActionListener getExitButtonAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
            
        };
    }
    
    private ActionListener getInstructionAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                instructionFrame.setVisible(true);
            }
            
        };
    }
    
    private ActionListener getAboutAL() {
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                aboutFrame.setVisible(true);
            }
            
        };
    }
    
    private ActionListener getCloseAL() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aboutFrame.setVisible(false);
            }
        };
    }
    
    protected void paintComponent(Graphics g) {
        super.paintComponents(g);
        g.drawImage(image, 0, 0, this);
    }
    
    public void setPanelLocation(JPanel panel, String position) {
        this.add(panel,position);
    }
    
    public void startGUI() {
        
        this.pack();
        centreFrame(this);
        this.setVisible(true);
    }
    
    public void centreFrame(ForceFrame frame) {
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int width = frame.getWidth();
        int height = frame.getHeight();
        int x = (dimension.width - width)/2;
        int y = (dimension.height - height)/2;
        
        frame.setLocation(x, y);
                
        //I love Johanna
    }
    
}
