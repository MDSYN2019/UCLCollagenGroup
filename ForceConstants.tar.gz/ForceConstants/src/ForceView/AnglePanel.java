/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import ForceConstantsIO.NumberDocumentFilter;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.text.*;

/**
 *
 * @author acnash
 */
public class AnglePanel extends JPanel {
    
    private JTextField fixedAtomTextField = null;
    private JTextField displacedAtomATextField = null;
    private JTextField displacedAtomCTextField = null;
    
    public AnglePanel(JTextField fixedAtomTextField, JTextField displacedAtomATextField, JTextField displacedAtomCTextField) {
        this.setLayout(new GridLayout(3,2));
        
        JLabel fixedLabel = new JLabel("Fixed Atom:");
        JLabel displacedALabel = new JLabel("Displaced Atom A:");
        JLabel displacedCLabel = new JLabel("Displaced Atom C:");
        this.fixedAtomTextField = fixedAtomTextField;
        this.displacedAtomATextField = displacedAtomATextField;
        this.displacedAtomCTextField = displacedAtomCTextField;
        
        Document fixedDoc = this.fixedAtomTextField.getDocument();
        AbstractDocument abFixedDoc = (AbstractDocument)fixedDoc;
        abFixedDoc.setDocumentFilter(new NumberDocumentFilter());
        this.fixedAtomTextField.setDocument(fixedDoc);
        
        Document displacedADoc = this.displacedAtomATextField.getDocument();
        AbstractDocument abDisplacedADoc = (AbstractDocument)displacedADoc;
        abDisplacedADoc.setDocumentFilter(new NumberDocumentFilter());
        this.displacedAtomATextField.setDocument(displacedADoc);
        
        Document displacedCDoc = this.displacedAtomCTextField.getDocument();
        AbstractDocument abDisplacedCDoc = (AbstractDocument)displacedCDoc;
        abDisplacedCDoc.setDocumentFilter(new NumberDocumentFilter());
        this.displacedAtomCTextField.setDocument(displacedCDoc);
        
        this.add(displacedALabel);
        this.add(this.displacedAtomATextField);
        this.add(fixedLabel);
        this.add(this.fixedAtomTextField);
        this.add(displacedCLabel);
        this.add(this.displacedAtomCTextField);
        
    }
    
    
    public int getFixedAtomTextField() {
        return Integer.getInteger(fixedAtomTextField.getText());
    }
    
    public int getDisplacedAtomATextField() {
        return Integer.getInteger(displacedAtomATextField.getText());
    }
    
    public int getDisplacedAtomCTextField() {
        return Integer.getInteger(displacedAtomCTextField.getText());
    }
}
