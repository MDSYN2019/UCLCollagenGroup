/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import ForceConstantsIO.NumberDocumentFilter;
import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;

/**
 *
 * @author acnash
 */
public class DistancePanel extends JPanel {
    
    private JTextField fixedAtomTextField = null;
    private JTextField displacedAtomTextField = null;
    
    public DistancePanel(JTextField fixedAtomTextField, JTextField displacedAtomTextField) {
        this.setLayout(new GridLayout(2,2));
        JLabel fixedLabel = new JLabel("Fixed Atom:");
        JLabel displacedLabel = new JLabel("Displaced Atom:");
        this.fixedAtomTextField = fixedAtomTextField;
        this.displacedAtomTextField = displacedAtomTextField;
        
        Document fixedDoc = this.fixedAtomTextField.getDocument();
        AbstractDocument abFixedDoc = (AbstractDocument)fixedDoc;
        abFixedDoc.setDocumentFilter(new NumberDocumentFilter());
        this.fixedAtomTextField.setDocument(fixedDoc);
        
        Document displacedDoc = this.displacedAtomTextField.getDocument();
        AbstractDocument abDisplacedDoc = (AbstractDocument)displacedDoc;
        abDisplacedDoc.setDocumentFilter(new NumberDocumentFilter());
        this.displacedAtomTextField.setDocument(displacedDoc);
        
        this.add(fixedLabel);
        this.add(this.fixedAtomTextField);
        this.add(displacedLabel);
        this.add(this.displacedAtomTextField);
    }
    
    
    public int getFixedAtomTextField() {
        return Integer.getInteger(fixedAtomTextField.getText());
    }
    
    public int getDisplacedAtomTextField() {
        return Integer.getInteger(displacedAtomTextField.getText());
    }
    
}
