/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceView;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author acnash
 */
public class InstructionFrame extends JFrame {
    
    private static final int WIDTH=500;
    private static final int HEIGHT=500;
    
    private final JPanel descriptionPanel = new JPanel();
    private final JTextPane textPane = new JTextPane();
    
    public InstructionFrame() {
        this.setSize(WIDTH, HEIGHT);
        centreFrame();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        InstructionFrame.setDefaultLookAndFeelDecorated(true);
        

        BorderLayout layout = new BorderLayout();
        this.setLayout(layout);
        textPane.setContentType("text/html");
        textPane.setText(getAboutDescription());
        textPane.setEditable(false);

        descriptionPanel.setLayout(new BorderLayout());
        descriptionPanel.add(textPane,BorderLayout.CENTER);
        JScrollPane scroll = new JScrollPane(textPane);

        this.add(scroll,BorderLayout.CENTER);

        super.setVisible(false);
    }
    
    @Override
    public void setVisible(boolean isVisible) {
        super.setVisible(isVisible);
    }
    
    private String getAboutDescription() {
        StringBuilder htmlBuilder = new StringBuilder();
        htmlBuilder.append("<html>");
        htmlBuilder.append("<body><p><center><b>Second order tensor force constant parameteriser instructions</b></center></p>");
        
        //without an atom file
        htmlBuilder.append("<p><b>Single force constant parameterisation use.</b></p>");
        htmlBuilder.append("<b>1.</b> Load a Gaussian .log/.out text file and a formatted Gaussian checkpoint file by selecting the respective file selection buttons towards the top of the application window.<br>");
        htmlBuilder.append("<b>2.</b> To change between bond stretch and bond angle force constant derivation use the combobox to the left of the applicaiton window.<br>");
        htmlBuilder.append("<b>3.</b> Enter the atom IDs as denoted in the Gaussian log file. A displaced atom during bond stretch force constant derivation is the atom which is displaced relative to a second atom which could be considered as fixed.<br>");
        htmlBuilder.append("The bond angle force constant derivation requires three atom IDs, two displaced atoms A and C (a combination of vibrations: scissoring and rocking), and a fixed atom B, to make the angle A-B-C. <br>");
        htmlBuilder.append("<b>4.</b> Derive the force constant by clicking the 'Calculate' button.<br><br>");
        htmlBuilder.append("The derived force constant will be reported in units compatible with the Amber MD code and the Gromacs MD code. The raw Hessian followed by the mass weighted Hessian are also visible in the output screen.<br>");
        
        htmlBuilder.append("<p><b>Multiple force constant parameterisation use through atom connectivity file description.</b></p>");
        htmlBuilder.append("An atom connectivity file provides an automated process of deriving multiple stretch or angle force constants at anyone time. It will also derive bond lengths and bond angles for Gromacs and bond lengths for Amber. These parameters are written to a single FC.dat file which can be used to populate frcmod.known and ffbonded.itp for Amber and Gromacs, respectively.<br><br>");
        htmlBuilder.append("<b>1.</b> Prepare an ASCII text file (best through Vi or emacs to avoid hidden metadata). For the derivation of bond stretch force constants the first line should read <b>Stretch</b>, otherwise <b>Angle</b>.<br>");
        htmlBuilder.append("<b>2.</b> Each additional line should only contain atom connectivity, avoid blank lines. For the software to retrieve the correct atom from the Gaussian files us the atom IDs to denote connectivity. For example over two individual files:<br><br>");
        htmlBuilder.append("<i>stretchfile.dat</i><br>");
        htmlBuilder.append("Stretch<br>");
        htmlBuilder.append("1 2<br>");
        htmlBuilder.append("2 3<br>");
        htmlBuilder.append("3 4<br>");
        htmlBuilder.append("10 11<br><br>");
        htmlBuilder.append("<i>anglefile.dat</i><br>");
        htmlBuilder.append("Angle<br>");
        htmlBuilder.append("1 2 3<br>");
        htmlBuilder.append("2 3 4<br>");
        htmlBuilder.append("3 4 5<br><br>");
        
        
        htmlBuilder.append("<b>3.</b>Atom types if provided are used to match the Gromacs and Amber library file format. This will result in equlibrium bond stretch and bond angle calculation. Simply add the atom types in your input <i>file.dat</i> file after each row of respective atom IDs. For example:<br><br>");
        htmlBuilder.append("<i>stretchfile.dat</i><br>");
        htmlBuilder.append("Stretch<br>");
        htmlBuilder.append("1 2 N CA<br>");
        htmlBuilder.append("2 3 CA C<br>");
        htmlBuilder.append("3 4 CA O<br><br>");
        htmlBuilder.append("<b>Note:</b> All atom types must be supplied, or no types at all. If no types are supplied, the regular output of atom IDs and force constants are saved. Providing atom types will result in the following format for bond stretch:<br><br>");
        htmlBuilder.append("GROMACS - atom types internal to Gromacs (supplied by user)<br>");
        htmlBuilder.append("i       j       func    len_eq(nm)      FC (kJ/mol/nm^2)<br><br>");
        htmlBuilder.append("AMBER - atom types internal to Amber (supplied by user)<br>");
        htmlBuilder.append("BOND    FC(kcal/mol/rad^2)      len_eq(Angstrom)<br><br>");
        htmlBuilder.append("And for bond angle for constants:<br><br>");
        htmlBuilder.append("AMBER - atom types internal to Amber (supplied by user)<br>");
        htmlBuilder.append("ANGLE   FC(kcal/mol/rad^2)      deg_eq(degree)<br><br>");
        htmlBuilder.append("GROMACS - atom types internal to Gromacs (supplied by user)<br>");
        htmlBuilder.append("i       j       k       func    deg_eq(degree)  FC (kJ/mol/rad^2)<br><br>");
        
        htmlBuilder.append("<b>4.</b> To derive the force constant from the input file, select the Atom Data button. Load the formatted .dat file.<br>");
        htmlBuilder.append("5. The force constant output will be stored in a FC.dat file in the same directory as the atom connectivity input file. <b>Warning</b> This program currently over writes the FC.dat file.<br><br> ");
        
        htmlBuilder.append("<p><b>Additional features to Version: 0.1</b></p>");
        
        htmlBuilder.append("</body></html>");
        
        String html = htmlBuilder.toString();
        
        return html;
    }
    
    private void centreFrame() {
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int width = this.getWidth();
        int height = this.getHeight();
        int x = (dimension.width - width)/2;
        int y = (dimension.height - height)/2;
        
        this.setLocation(x, y);
                
        //I love Johanna
    }
}
