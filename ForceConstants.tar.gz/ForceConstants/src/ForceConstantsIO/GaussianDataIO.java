/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package ForceConstantsIO;

import ForceView.OutputPanel;
import forceconstants.ForceConstants;
import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author acnash
 */
public class GaussianDataIO {
    
    private static final String FCHK_EXTENSION = "fchk";
    private static final String LOG_EXTENSION = "log";
    private static final String OUT_EXTENSION = "out";
    private static final String ATOM_EXTENSION = "dat";
    
    private static GaussianDataIO instance = null;
    
    private boolean withAtomTypes = false;
    
    private File fchkFile = null;
    private File logFile = null;
    private File atomFile = null;
    
    private boolean loadedFCHKFile = false;
    private boolean loadedLogFile = false;
   
    //this is the problem - this must always be null
    private List<String> fcLines = null;// new ArrayList<>();
    private List<int[]> listAtomStretch = null;
    private List<int[]> listAtomAngle = null;
    private List<String[]> listAtomTypes = null;
    //private List<String> dispLines = null; //new ArrayList<>();
    
    private String[][] distanceCoords = new String[2][3];
    private String[][] angleCoords = new String[3][3];
    
    private OutputPanel outputPanel = null;
    
    protected GaussianDataIO(OutputPanel outputPanel) {
        this.outputPanel = outputPanel;
    
    }
    
    public static GaussianDataIO getInstance(OutputPanel outputPanel) {
        if(instance == null) {
            instance = new GaussianDataIO(outputPanel);
        }
        return instance;
    }
    
    public String[][] getXYZcoordsBohr(int angleDistance, String[] atomIDs) throws IOException {
        
        if(angleDistance == ForceConstants.DISTANCE) {
            String displacedAtomID = atomIDs[0];
            String[] displacedAtomCoords = getAtomIDCoords(displacedAtomID);
            String atomAID = atomIDs[1];
            String[] atomAIDCoords = getAtomIDCoords(atomAID);
            
            
            //from Angstrom (in log file) to Bohr radius for multiplication with the hessian 
            displacedAtomCoords[0] = String.valueOf(Double.valueOf(displacedAtomCoords[0])/0.529177);
            displacedAtomCoords[1] = String.valueOf(Double.valueOf(displacedAtomCoords[1])/0.529177);
            displacedAtomCoords[2] = String.valueOf(Double.valueOf(displacedAtomCoords[2])/0.529177);
            
            atomAIDCoords[0] = String.valueOf(Double.valueOf(atomAIDCoords[0])/0.529177);
            atomAIDCoords[1] = String.valueOf(Double.valueOf(atomAIDCoords[1])/0.529177);
            atomAIDCoords[2] = String.valueOf(Double.valueOf(atomAIDCoords[2])/0.529177);
            
            
            
            distanceCoords[0][0] = displacedAtomCoords[0];
            distanceCoords[0][1] = displacedAtomCoords[1];
            distanceCoords[0][2] = displacedAtomCoords[2];
            distanceCoords[1][0] = atomAIDCoords[0];
            distanceCoords[1][1] = atomAIDCoords[1];
            distanceCoords[1][2] = atomAIDCoords[2];
            
            return distanceCoords;
        } else {
            String displacedAtomID = atomIDs[0];
            String[] displacedAtomCoords = getAtomIDCoords(displacedAtomID);
            String atomAID = atomIDs[1];
            String[] atomAIDCoords = getAtomIDCoords(atomAID);
            String atomCID = atomIDs[2];
            String[] atomCIDCoords = getAtomIDCoords(atomCID);
            
            angleCoords[0][0] = displacedAtomCoords[0];
            angleCoords[0][1] = displacedAtomCoords[1];
            angleCoords[0][2] = displacedAtomCoords[2];
            angleCoords[1][0] = atomAIDCoords[0];
            angleCoords[1][1] = atomAIDCoords[1];
            angleCoords[1][2] = atomAIDCoords[2];
            angleCoords[2][0] = atomCIDCoords[0];
            angleCoords[2][1] = atomCIDCoords[1];
            angleCoords[2][2] = atomCIDCoords[2];
            
            return angleCoords;
        }
                
    }
    
    public String[][] getXYZcoords(int angleDistance, String[] atomIDs) throws IOException {
        
        if(angleDistance == ForceConstants.DISTANCE) {
            String displacedAtomID = atomIDs[0];
            String[] displacedAtomCoords = getAtomIDCoords(displacedAtomID);
            String atomAID = atomIDs[1];
            String[] atomAIDCoords = getAtomIDCoords(atomAID);
            
            
            //from Angstrom (in log file) to Bohr radius for multiplication with the hessian 
            displacedAtomCoords[0] = String.valueOf(Double.valueOf(displacedAtomCoords[0]));
            displacedAtomCoords[1] = String.valueOf(Double.valueOf(displacedAtomCoords[1]));
            displacedAtomCoords[2] = String.valueOf(Double.valueOf(displacedAtomCoords[2]));
            
            atomAIDCoords[0] = String.valueOf(Double.valueOf(atomAIDCoords[0]));
            atomAIDCoords[1] = String.valueOf(Double.valueOf(atomAIDCoords[1]));
            atomAIDCoords[2] = String.valueOf(Double.valueOf(atomAIDCoords[2]));
            
            
            
            distanceCoords[0][0] = displacedAtomCoords[0];
            distanceCoords[0][1] = displacedAtomCoords[1];
            distanceCoords[0][2] = displacedAtomCoords[2];
            distanceCoords[1][0] = atomAIDCoords[0];
            distanceCoords[1][1] = atomAIDCoords[1];
            distanceCoords[1][2] = atomAIDCoords[2];
            
            return distanceCoords;
        } else {
            String displacedAtomID = atomIDs[0];
            String[] displacedAtomCoords = getAtomIDCoords(displacedAtomID);
            String atomAID = atomIDs[1];
            String[] atomAIDCoords = getAtomIDCoords(atomAID);
            String atomCID = atomIDs[2];
            String[] atomCIDCoords = getAtomIDCoords(atomCID);
            
            angleCoords[0][0] = displacedAtomCoords[0];
            angleCoords[0][1] = displacedAtomCoords[1];
            angleCoords[0][2] = displacedAtomCoords[2];
            angleCoords[1][0] = atomAIDCoords[0];
            angleCoords[1][1] = atomAIDCoords[1];
            angleCoords[1][2] = atomAIDCoords[2];
            angleCoords[2][0] = atomCIDCoords[0];
            angleCoords[2][1] = atomCIDCoords[1];
            angleCoords[2][2] = atomCIDCoords[2];
            
            return angleCoords;
        }
                
    }
    
    private String[] getAtomIDCoords(String atomID) throws IOException {
        String[] coords = new String[3];
        
        List<String> lines = Files.readAllLines(logFile.toPath());
        ListIterator<String> listIterator = lines.listIterator();
        String coordLine = null;
        while(listIterator.hasNext()) {
            String line = listIterator.next();
            
            
            if(line.contains("Standard orientation")) {
                //Go through the header data,
                for(int i=0; i<4; i++) {
                    line = listIterator.next();
                }
                int i=1;
                //int id = Integer.getInteger(atomID);
                int id = Integer.valueOf(atomID);
                while(i<=id) {
                    coordLine = listIterator.next();
                    i++;
                }
            }
            
        }
        
        String[] splitString = coordLine.split("\\s+");
        coords[0] = splitString[4];
        coords[1] = splitString[5];
        coords[2] = splitString[6];
        
        return coords;
        
    }
    
    public void setAtomDataFile(File file) throws NullPointerException, FileNotFoundException, IOException {
        if(file == null) {
            throw new NullPointerException("Atom data file is null.");
        }
        if(file.exists() == false) {
            throw new FileNotFoundException("Atom data file can not be found");
        }
        StringTokenizer st = new StringTokenizer(file.getName(),"\\.");
        String extension = null;
        while(st.hasMoreTokens()) {
            extension = st.nextToken();
        }
        if(extension == null) {
            throw new NullPointerException("Unknown atom data file format");
        }
        if(extension.compareTo(ATOM_EXTENSION) != 0) {
            throw new FileNotFoundException("Unknown atom data file extension");
        }
        atomFile = file;
        readInAtomData();
    }
    
    public void setFCHKFile(File file) throws NullPointerException, FileNotFoundException {
        if(file == null) {
            throw new NullPointerException("FCHK file is null.");
        }
        if(file.exists() == false) {
            throw new FileNotFoundException("FCHK file can not be found");
        }
        StringTokenizer st = new StringTokenizer(file.getName(),"\\.");
        String extension = null;
        while(st.hasMoreTokens()) {
            extension = st.nextToken();
        }
        if(extension == null) {
            throw new NullPointerException("Unknown FCHK file format");
        }
        if(extension.compareTo(FCHK_EXTENSION) != 0) {
            throw new FileNotFoundException("Unknown FCHK file extension");
        }
        
        fchkFile = file;
        loadedFCHKFile = true;
        outputPanel.setText("\nLoading formatted checkpoint file: " + fchkFile.getAbsolutePath());
    }
    
    public void setLogFile(File file) throws NullPointerException, FileNotFoundException {
        if(file == null) {
            throw new NullPointerException("Log file is null.");
        }
        if(file.exists() == false) {
            throw new FileNotFoundException("Log file can not be found");
        }
        
        StringTokenizer st = new StringTokenizer(file.getName(),"\\.");
        String extension = null;
        while(st.hasMoreTokens()) {
            extension = st.nextToken();
        }
        if(extension == null) {
            throw new NullPointerException("Unknown LOG file format");
        }
        if(extension.compareTo(OUT_EXTENSION) != 0 && extension.compareTo(LOG_EXTENSION) != 0) {
            throw new FileNotFoundException("Unknown LOG file extension");
        }
        
        logFile = file;
        loadedLogFile = true;
        outputPanel.setText("\nLoading log file" + logFile.getAbsolutePath() + "\n");
    }
    
    
    private void readInAtomData() throws IOException {
        boolean isAngle = false;
        boolean isStretch = false;
        List<String> lines = Files.readAllLines(atomFile.toPath());
        ListIterator<String> listIterator = lines.listIterator();
        listAtomTypes = new ArrayList<String[]>();
        while(listIterator.hasNext()) {
            String line = listIterator.next();
            if((line.toLowerCase()).contains("stretch")) {
                ForceConstants.selectedAngleDistance = ForceConstants.DISTANCE;
                listAtomStretch = new ArrayList<int[]>();
                isStretch = true;
                isAngle = false;
            } else if((line.toLowerCase()).contains("angle")) {
                ForceConstants.selectedAngleDistance = ForceConstants.ANGLE;
                listAtomAngle = new ArrayList<int[]>();
                isAngle = true;
                isStretch = false;
            } else {
                String[] atomIds = line.split("\\s");
                if(isStretch) {
                    int[] id = new int[2]; 
                    id[0] = Integer.parseInt(atomIds[0]);
                    id[1] = Integer.parseInt(atomIds[1]);
                    if(atomIds.length == 4) {
                        withAtomTypes = true;
                        String[] atomtypes = new String[2];
                        atomtypes[0] = atomIds[2];
                        atomtypes[1] = atomIds[3];
                        listAtomTypes.add(atomtypes);
                    } else {
                        withAtomTypes = false;
                        
                    }
                    listAtomStretch.add(id);
                } 
                if(isAngle) {
                    int[] id = new int[3]; 
                    id[0] = Integer.parseInt(atomIds[0]);
                    id[1] = Integer.parseInt(atomIds[1]);
                    id[2] = Integer.parseInt(atomIds[2]);
                    if(atomIds.length == 6) {
                        withAtomTypes = true;
                        String[] atomtypes = new String[3];
                        atomtypes[0] = atomIds[3];
                        atomtypes[1] = atomIds[4];
                        atomtypes[2] = atomIds[5];
                        listAtomTypes.add(atomtypes);
                    } else {
                        withAtomTypes = false;
                    }
                    listAtomAngle.add(id);
                }
            }
            
            
        }
    }
    
    public List<int[]> getAngleList() {
        return listAtomAngle;
    }
    
    public List<int[]> getStretchList() {
        return listAtomStretch;
    }
    
    public boolean loadForceConstants() throws IOException {
        if(loadedFCHKFile == false) {
            JOptionPane.showMessageDialog(outputPanel, "The FCHK file has not been loaded.", "File error", JOptionPane.ERROR_MESSAGE);
            //System.out.println("The FCHK file has not been loaded. ");
            return false;
        }
        
        fcLines = new ArrayList();
        
        boolean foundFC = false;
        List<String> lines = Files.readAllLines(fchkFile.toPath());
        ListIterator<String> listIterator = lines.listIterator();
        while(listIterator.hasNext()) {
            String line = listIterator.next();
            if(foundFC == true) {
                if(line.contains("Dipole Moment")) {
                    //System.out.println("End of FCs");
                    break;
                } else {
                    fcLines.add(line);
                    //System.out.println(line);
                }
            }
            
            if(line.contains("Cartesian Force Constants")) {
                //System.out.println("Found FCs");
                foundFC = true;
            }
        }
        
        if(foundFC == false) {
            JOptionPane.showMessageDialog(outputPanel, "Wasn't able to find the FCs in the FCHK file.", "FCHK error", JOptionPane.ERROR_MESSAGE);
            //System.out.println("Wasn't able to find the FCs in the FCHK");
            return false;
        }
        
        return true;
    }
    
    public List<String> getFCLines() {
        return fcLines;
    }
    
    
    public boolean loadDisplacement(int normalModeNumber) throws IOException {
        return true;
        /*
        if(loadedLogFile == false) {
            System.out.println("The Log file has not been loaded. ");
            return false;
        }
        if(normalModeNumber < 1) {
            System.out.println("No such thing as a negative normal mode");
            return false;
        }
        
        boolean foundDisp = false;
        int dispCount = 0;
        List<String> lines = Files.readAllLines(logFile.toPath());
        ListIterator<String> listIterator = lines.listIterator();
        while(listIterator.hasNext()) {
            String line = listIterator.next();
            
            
            if(line.contains("Atom  AN")) {
                System.out.println("\nFound some displacement data");
                //foundDisp = true;
                
                dispCount++;
                if(normalModeNumber == dispCount) {
                    dispLines = getDispData(listIterator, 1, normalModeNumber);
                    foundDisp = true;
                    break;
                } 
                dispCount++;
                if(normalModeNumber == dispCount) {
                    dispLines = getDispData(listIterator, 2, normalModeNumber);
                    foundDisp = true;
                    break;
                }
                dispCount++;
                if(normalModeNumber == dispCount) {
                    dispLines = getDispData(listIterator, 3, normalModeNumber);
                    foundDisp = true;
                    break;
                }
                
            }
        }
        
        if(foundDisp == false) {
            System.out.println("Wasn't able to find the displacement data in the log file");
            return false;
        }
        
        return true;
        */
    }
    
    private List<String> getDispData(ListIterator<String> listIterator, int column, int normalModeNumber) {
        System.out.println("Retrieving normal mode displacement data for " + normalModeNumber + " in column " + column);
        List<String> dispList = new ArrayList<>();
        while(listIterator.hasNext()) {
            String dispEntry = listIterator.next();
            
            //this check wihat happns with 5 modes
            if(dispEntry.matches("\\s*") || dispEntry.matches("^\\s+\\d+\\s+\\d+\\s+\\d+")) {
                System.out.println("End of displacement data");
                break;
            }
            
            StringTokenizer strToken = new StringTokenizer(dispEntry);
            List<String> singleLineList = new ArrayList<>();
            while(strToken.hasMoreTokens()) {
                singleLineList.add(strToken.nextToken());
            }
            String desiredTriple = null;
            if(column == 1) {
                desiredTriple = singleLineList.get(2) + " " + singleLineList.get(3) + " " + singleLineList.get(4);
            } 
            if(column == 2) {
                desiredTriple = singleLineList.get(5) + " " + singleLineList.get(6) + " " + singleLineList.get(7);
            }
            if(column == 3) {
                desiredTriple = singleLineList.get(8) + " " + singleLineList.get(9) + " " + singleLineList.get(10);
            }
            
            System.out.println(desiredTriple);
            dispList.add(desiredTriple);
        }
        
        return dispList;
        
    }
    
    public void outputFCDistanceAngle(ArrayList fcAmberList, ArrayList fcGromacsList, ArrayList distanceAngleList, int type) throws IOException {
        File outputFile = new File(atomFile.getParent() + "/FCs.dat");
        FileWriter write = new FileWriter(outputFile.getPath(),false);
        PrintWriter printLine = new PrintWriter(write);
        
        if(type == ForceConstants.DISTANCE) {
            printLine.println("BOND STRETCH");
            printLine.println("\nAMBER");
            printLine.println("i\tj\tFC (kcal/mol/a^2)");
            
            ArrayList<int[]> atomList = (ArrayList)getStretchList();
            ListIterator amberAtomListIterator = atomList.listIterator();
            ListIterator gromacsAtomListIterator = atomList.listIterator();
            
            ListIterator listIterator = fcAmberList.listIterator();
            while(listIterator.hasNext()) {
                int[] atoms = (int[])amberAtomListIterator.next();
                double fc = (double)listIterator.next();
                printLine.println(atoms[0] + "\t" + atoms[1] + "\t" +fc);
            }
            printLine.println("\nGROMACS - atom IDs (internal to the supplied Gaussian log file");
            printLine.println("i\tj\tFC (kJ/mol/nm^2)");
            listIterator = fcGromacsList.listIterator();
            while(listIterator.hasNext()) {
                int[] atoms = (int[])gromacsAtomListIterator.next();
                double fc = (double)listIterator.next();
                printLine.printf("%d\t%d\t%.3f\n",atoms[0],atoms[1],fc);
            }
            
            if(withAtomTypes == true) {
                //AMBER
                printLine.println("\nAMBER - atom types internal to Amber (supplied by user)");
                printLine.println("BOND\tFC(kcal/mol/rad^2)\tlen_eq(Angstrom)");
                listIterator = fcAmberList.listIterator();
                ListIterator<String[]> atomTypeIterator = listAtomTypes.listIterator();
                ListIterator distanceIterator = distanceAngleList.listIterator();
                while(atomTypeIterator.hasNext()) {
                    String[] atomtypes = atomTypeIterator.next();
                    double distance = (double)distanceIterator.next();
                    double fc = (double)listIterator.next();
                    printLine.printf("%s-%s\t%.1f\t%.2f\n",atomtypes[0],atomtypes[1],fc,distance);
                }
                
                //GROMACS
                printLine.println("\nGROMACS - atom types internal to Gromacs (supplied by user)");
                printLine.println("i\tj\tfunc\tlen_eq(nm)\tFC (kJ/mol/nm^2)");
                listIterator = fcGromacsList.listIterator();
                atomTypeIterator = listAtomTypes.listIterator();
                distanceIterator = distanceAngleList.listIterator();
                while(atomTypeIterator.hasNext()) {
                    String[] atomtypes = atomTypeIterator.next();
                    double distance = (double)distanceIterator.next();
                    //int[] atoms = (int[])gromacsAtomListIterator.next();
                    double fc = (double)listIterator.next();
                    printLine.printf("%s\t%s\t1\t%.3f\t\t%.3f\n",atomtypes[0],atomtypes[1],(distance/10),fc);
                    //printLine.printf("%s\t%s\t%s\t1\t%.3f\t%.3f\n",atomtypes[0],atomtypes[1],atomtypes[2],angle,fc);
                }
            }
            
        } else {
            printLine.println("BOND ANGLE");
            printLine.println("\nAMBER");
            printLine.println("i\tj\tk\tFC (kcal/mol/rad^2)");
            ArrayList<int[]> atomList = (ArrayList)getAngleList();
            ListIterator amberAtomListIterator = atomList.listIterator();
            ListIterator gromacsAtomListIterator = atomList.listIterator();
            
            ListIterator listIterator = fcAmberList.listIterator();
            while(listIterator.hasNext()) {
                int[] atoms = (int[])amberAtomListIterator.next();
                double fc = (double)listIterator.next();
                printLine.println(atoms[0] + "\t" + atoms[1] + "\t" + atoms[2] + "\t" + fc);
            }
            printLine.println("\nGROMACS - atom IDs (internal to the supplied Gaussian log file)");
            printLine.println("i\tj\tk\tFC (kJ/mol/rad^2)");
            listIterator = fcGromacsList.listIterator();
            while(listIterator.hasNext()) {
                int[] atoms = (int[])gromacsAtomListIterator.next();
                double fc = (double)listIterator.next();
                printLine.printf("%s\t%s\t%s\t%.3f\n",atoms[0],atoms[1],atoms[2],fc);
            }
            
            if(withAtomTypes == true) {
                //AMBER
                printLine.println("\nAMBER - atom types internal to Amber (supplied by user)");
                printLine.println("ANGLE\tFC(kcal/mol/rad^2)\tdeg_eq(degree)");
                listIterator = fcAmberList.listIterator();
                ListIterator<String[]> atomTypeIterator = listAtomTypes.listIterator();
                ListIterator angleIterator = distanceAngleList.listIterator();
                while(atomTypeIterator.hasNext()) {
                    double angle = (double)angleIterator.next();
                    angle = angle*57.2958;
                    String[] atomtypes = atomTypeIterator.next();
                    double fc = (double)listIterator.next();
                    printLine.printf("%s-%s-%s\t%.1f\t%.2f\n",atomtypes[0],atomtypes[1],atomtypes[2],fc,angle);
                }
                
                //GROMACS
                printLine.println("\nGROMACS - atom types internal to Gromacs (supplied by user)");
                printLine.println("i\tj\tk\tfunc\tdeg_eq(degree)\tFC (kJ/mol/rad^2)");
                listIterator = fcGromacsList.listIterator();
                atomTypeIterator = listAtomTypes.listIterator();
                angleIterator = distanceAngleList.listIterator();
                while(atomTypeIterator.hasNext()) {
                    //int[] atoms = (int[])gromacsAtomListIterator.next();
                    double angle = (double)angleIterator.next();
                    angle = angle*57.2958;
                    String[] atomtypes = atomTypeIterator.next();
                    double fc = (double)listIterator.next();
                    printLine.printf("%s\t%s\t%s\t1\t%.3f\t\t%.3f\n",atomtypes[0],atomtypes[1],atomtypes[2],angle,fc);
                }
            }
        }
        
        
        
        printLine.close();
    }
    
    
    
    
    /**
     * 
     * @param atomID must minus 1. Gaussian starts from 1 (atom ID) but entries in
     * array index begin from 0.
     * @return 
     */
//    public List<String> getDispLines(int atomID) {
//        String[] entries = dispLines.get(atomID-1).split(" ");
//        List<String> dispVector = new ArrayList<>();
//        dispVector.add(entries[0]);
//        dispVector.add(entries[1]);
//        dispVector.add(entries[2]);
//        
//        return dispVector;
//    }
}
