/*
   Copyright (C) 2016  Anthony Nash

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    a.nash@ucl.ac.uk
 */
package Test;

/**
 *
 * @author acnash
 */

import Jama.EigenvalueDecomposition;
import Jama.Matrix;
import org.apache.commons.math3.linear.*;

public class TestEigen {
    
    private RealMatrix hessian = null;
    
    public TestEigen(int q) {
        if(q==0) {
            testVectors();
        }
        
        double[][] dataA = new double[9][9];
        double[][] dataB = new double[9][9];
        
        for(int i=0; i<9; i++) {
            for(int j=0; j<9; j++) {
                if(i==j) {
                    dataA[i][j] = 16;
                    dataB[i][j] = 15;
                }
            }
        }
        
        
        Matrix massMatrixA = new Matrix(dataA);
        Matrix massMatrixB = new Matrix(dataB);
        
        Matrix mulMatrix = massMatrixB.times(massMatrixA);
        for(int i=0; i<9; i++) {
            for(int j=0; j<9; j++) {
                if(i==j) {
                    mulMatrix.set(i, j, Math.sqrt(mulMatrix.get(i, j)));
                }
            }
        }
        
        System.out.println("End");
    }
    
    private void testVectors() {
        double[][] data = new double[3][3];
        data[0][0] = 5.05322467E-7; 
        data[0][1] = -4.01053696E-17; 
        data[0][2] = 4.78630065E-17;
        data[1][0] = 9.69906679E-18; 
        data[1][1] = -0.401977069; 
        data[1][2] = 0.337136946;
        data[2][0] = 2.39239207E-17; 
        data[2][1] = 0.216312144; 
        data[2][2] = -0.317449158;
        
        //data[0][0] = 195;
        //data[0][1] = 285;
        //data[0][2] = 375;
        //data[1][0] = 465;
        //data[1][1] = 555;
        //data[1][2] = 645;
        //data[2][0] = 735;
        //data[2][1] = 825;
        //data[2][2] = 915;
        hessian = MatrixUtils.createRealMatrix(data);
        EigenDecomposition ed = new EigenDecomposition(hessian);
        double[] eigenValues = ed.getRealEigenvalues();
        
        System.out.println(eigenValues[0]);
        System.out.println(eigenValues[1]);
        System.out.println(eigenValues[2]);
        
        RealVector[] eigenVectorC = new RealVector[3];
        for(int i=0; i<3; i++) {
            eigenVectorC[i] = ed.getEigenvector(i);
        }
        for(int i=0; i<2; i++) {
            for(int j=0; j<3; j++) {
                double value = (eigenVectorC[i].getEntry(j))*-1;
                eigenVectorC[i].setEntry(j, value); 
            }
        }
        
        System.out.println("");
        System.out.println(eigenVectorC[0].getEntry(0) + " " + eigenVectorC[0].getEntry(1) + " " + eigenVectorC[0].getEntry(2));
        System.out.println(eigenVectorC[1].getEntry(0) + " " + eigenVectorC[1].getEntry(1) + " " + eigenVectorC[1].getEntry(2));
        System.out.println(eigenVectorC[2].getEntry(0) + " " + eigenVectorC[2].getEntry(1) + " " + eigenVectorC[2].getEntry(2));
    
    
        //double[][] array = {{1.,2.,3},{4.,5.,6.},{7.,8.,10.}};
        Matrix A = new Matrix(data);
        EigenvalueDecomposition jamaED = new EigenvalueDecomposition(A);
        double[] javaEV = jamaED.getRealEigenvalues();
        
        System.out.println();
        System.out.println("JAMA eigenvalues");
        for(int i=0; i<3; i++) {
            System.out.println(javaEV[i]);
        }
        Matrix V = jamaED.getV();
        System.out.println();
    }
    
    public static void main(String[] args) {
        new TestEigen(1);
        
    }
}
